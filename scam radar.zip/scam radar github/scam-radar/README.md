# Scam Radar

An explainable AI scam detector built as a third-year portfolio project. Paste a message, a raw email, a document, or a recorded call to get a **SCAM / LEGIT** verdict, confidence score, risk level, plain-English warning signals, and persistent history.

![Stack](https://img.shields.io/badge/stack-Flask%20%2B%20React-111111) ![NLP](https://img.shields.io/badge/NLP-TF--IDF%20%2B%20Logistic%20Regression-b8ff42)

## Live Demo

- **Website:** https://supritbanerjee.pythonanywhere.com/
- **API Health:** https://supritbanerjee.pythonanywhere.com/api/health
- **Source Code:** https://github.com/supritbanerjee/scamshield-ai

> The free PythonAnywhere web app may require a reload after a period of inactivity.


## Highlights

- Four input types: pasted message, raw email, uploaded document, and recorded voice
- Real NLP pipeline: word + character TF-IDF and logistic regression
- Email header forensics: spoofed senders, hijacked Reply-To, SPF/DKIM/DMARC failures, and links whose text hides their destination
- File forensics the classifier cannot see: PDF JavaScript, auto-run actions, Word macros, disguised double extensions
- Vishing rules for call transcripts: read-out codes, remote access, arrest threats, gift-card demands
- Explainable rule layer for links, urgency, payments, credential requests, threats, and remote access
- Scam-awareness quiz: five questions per round drawn from a bank of fifteen, marked server-side
- REST API with validation, CORS, JSON errors, and security headers
- SQLite scan history with delete-one and clear-all actions
- Original responsive React interface with custom AI-generated project artwork
- Singapore-aware corpus: Singpass and bank phishing, PayNow requests, SingPost and customs parcels, job scams, Singapore Sweep prizes, and government impersonation

## Project structure

```text
scam-detector/
├── backend/
│   ├── app.py          # Flask API, SQLite, and production React serving
│   └── model.py        # NLP training, inference, and explanations
├── frontend/
│   ├── public/         # Original project imagery
│   └── src/            # React UI and responsive CSS
├── tests/              # Flask API smoke tests
├── package.json        # Optional static build helper
├── Dockerfile          # Optional portable container deployment
├── PYTHONANYWHERE_DEPLOYMENT.md  # Free one-service deployment guide
├── requirements.txt
└── README.md
```

## Free live deployment — no card

The complete app can run from one free **PythonAnywhere Beginner** web app:

- React is built locally with Vite and the production `frontend/dist` output is committed to GitHub.
- Flask serves the compiled React site and all `/api` routes from the same domain.
- scikit-learn runs the NLP detector and SQLite stores demo history.
- No Docker, GPU, paid database, custom domain, or hosting card is needed.

See **[PYTHONANYWHERE_DEPLOYMENT.md](PYTHONANYWHERE_DEPLOYMENT.md)** for the complete guide. The `Dockerfile` remains only as an optional portable configuration.

## Run locally

### 1. Start the Flask API

```bash
cd scam-detector
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python backend/app.py
```

The API runs at `http://localhost:5000`.

### 2. Start the React frontend

Open a second terminal:

```bash
cd scam-detector/frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## API

| Method | Route | Purpose |
|---|---|---|
| `GET` | `/api/health` | Service and model status |
| `GET` | `/api/capabilities` | Which optional readers this server has |
| `POST` | `/api/analyze` | Analyze `{ "message": "..." }` |
| `POST` | `/api/analyze-email` | Analyze `{ "raw": "..." }` or an uploaded `.eml` |
| `POST` | `/api/analyze-file` | Analyze an uploaded PDF, DOCX, TXT, or screenshot |
| `POST` | `/api/analyze-audio` | Analyze an audio upload or `{ "transcript": "..." }` |
| `GET` | `/api/quiz` | Five random quiz questions, answers withheld |
| `POST` | `/api/quiz/answer` | Mark `{ "id": "...", "choice": 0 }` and return the explanation |
| `POST` | `/api/quiz/result` | Turn a finished round into feedback |
| `GET` | `/api/history?limit=20` | Get recent scans and totals |
| `DELETE` | `/api/history/:id` | Delete one scan |
| `DELETE` | `/api/history` | Clear all history |

Example:

```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"message":"Urgent! Your KYC expires today. Click this link and share OTP."}'
```

## Input types

| Input | How text is obtained | Extra evidence gathered |
|---|---|---|
| Message | Pasted directly | Wording only |
| Email | Headers and body parsed with Python's `email` module | Reply-To and Return-Path mismatch, brand impersonation, SPF/DKIM/DMARC results, anchor-text vs href mismatch, dangerous attachments |
| Document | `pypdf`, `python-docx`, or built-in OCR for screenshots | Embedded JavaScript, auto-run actions, macros, link annotations, double extensions |
| Voice | `faster-whisper` on the server, or the browser's Web Speech API | Call-only patterns: read-out codes, "don't hang up", remote access, arrest threats |

Structural findings are blended into the probability with a soft-OR, capped so a single
finding never fully overrides the language model, and every finding is listed in the result.

`GET /api/capabilities` reports which optional readers are installed, and the React UI
hides what the server cannot do rather than failing at upload time.

## Pages

The frontend is a small single-page app with real URLs rather than one long scroll:

| Path | Page |
|---|---|
| `/` | Home, with the demo thread and links into the rest |
| `/scan` | The inspector: message, email, document, voice |
| `/method` | How the two layers work |
| `/quiz` | Scam-awareness quiz |
| `/history` | Past scans |
| `/faq` | Questions |

Navigation uses the History API, so pages can be bookmarked, refreshed and shared, and the
browser's back button works. Flask serves `index.html` for any unknown path
(`serve_frontend_asset`), which is what makes a direct load of `/quiz` work.

## The quiz

`GET /api/quiz` returns five questions sampled at random from `backend/quiz.py`, with the
correct index and explanation stripped out. The browser posts each choice to
`/api/quiz/answer`, which marks it and returns the reasoning, then `/api/quiz/result` turns
the final score into feedback.

Keeping the answers on the server means they cannot be read out of the built JavaScript, and
sampling five from fifteen means a second attempt is rarely the same round.

## How the model works

1. A small labelled seed corpus is vectorised from two views: word 1–2 grams and character 3–5 grams.
2. Logistic regression estimates scam probability.
3. A deterministic rule layer identifies high-risk patterns and creates explanations.
4. The scores are blended; the UI shows both the final confidence and the evidence.

This makes the project easy to run locally and discuss in an interview. For production, replace the seed corpus with a larger reviewed dataset, calibrate probabilities on a held-out test set, add multilingual support, and avoid retaining raw messages by default.

## Test and evaluate

```bash
pip install -r requirements-dev.txt
pytest -q
python backend/evaluate.py
```

## Optional extras

Everything, screenshot reading included, works from `requirements.txt` alone. Two upgrades
are available if you want them:

```bash
pip install -r requirements-optional.txt
```

- **`winocr`** swaps in the OCR built into Windows 10 and 11. It is faster than the bundled
  engine and spaces words more reliably. Windows only; the marker in the file skips it elsewhere.
- **`faster-whisper`** transcribes voice notes on the server instead of in the browser. It needs
  FFmpeg, is about 300 MB installed, and will not fit a free PythonAnywhere account.

If you already have Tesseract installed, it is picked up automatically and used ahead of the
bundled engine. Nothing needs configuring either way.
## Screenshots

### Home

![Scam Radar home page](docs/screenshots/01-home.png)

### The inspector

![Inspector](docs/screenshots/02-scan.png)

### A message on the bench

![Message analysis](docs/screenshots/03-message.png)

### Email, readable and raw

The Email tab renders the message like a mail client, while the raw source stays one click away.

![Readable email view](docs/screenshots/04-email-readable.png)

Header evidence is listed above the language signals, because it is the harder proof.

![Email verdict](docs/screenshots/05-email-verdict.png)

### Voice transcript

![Voice scam analysis](docs/screenshots/06-voice.png)

### Quiz

![Scam awareness quiz](docs/screenshots/07-quiz.png)

### Method

![How it decides](docs/screenshots/08-method.png)

### Scan history

Every scan is tagged with the input it came from.

![Scan history](docs/screenshots/09-history.png)
