"""A short scam-awareness quiz, drawn from a bank of questions.

Answers and explanations never leave this module until a choice is submitted,
so they cannot be read out of the frontend bundle. Each round is a random
sample, which means a second attempt is rarely the same five questions.

Questions are written around what Singapore actually sees: Singpass and bank
phishing, PayNow requests, parcel and customs holds, job scams, and the
"safe account" script used by callers impersonating the police.
"""
from __future__ import annotations

import random
from typing import Any

QUESTION_BANK: list[dict[str, Any]] = [
    {
        "id": "reply-to",
        "prompt": "Which of these is the strongest evidence that an email is phishing?",
        "options": [
            "It contains a spelling mistake",
            "The Reply-To address is on a different domain from the From address",
            "It arrived in the middle of the night",
            "It has an attachment",
        ],
        "answer": 1,
        "explanation": (
            "Anyone can write badly, send mail at odd hours, or attach a file. A Reply-To that "
            "redirects your reply to a different domain is deliberate, and it is how a scammer "
            "captures the conversation while the From line still shows a name you trust."
        ),
    },
    {
        "id": "otp-call",
        "prompt": "Someone calls, says they are from your bank's fraud team, and asks you to read out the OTP you just received. What should you do?",
        "options": [
            "Read it out, since the bank called you rather than the other way round",
            "Read out only the last three digits",
            "Hang up and call the number printed on your card or in the official app",
            "Ask them to email the request instead",
        ],
        "answer": 2,
        "explanation": (
            "Caller ID can be spoofed, so an incoming call proves nothing about who is on the "
            "line. No bank ever needs your OTP. Hanging up and dialling a number you already had "
            "is the only step that actually verifies who you are talking to."
        ),
    },
    {
        "id": "lookalike-domain",
        "prompt": "A message about your bank account contains a link. Which address actually belongs to DBS?",
        "options": [
            "dbs.com.sg.account-verify.net",
            "dbs-secure-login.com",
            "www.dbs.com.sg",
            "bit.ly/dbs-verify",
        ],
        "answer": 2,
        "explanation": (
            "Read a domain from the right. The real owner is the part just before the final "
            "suffix, so dbs.com.sg.account-verify.net belongs to account-verify.net, not DBS. "
            "A shortener hides the destination completely."
        ),
    },
    {
        "id": "safe-account",
        "prompt": "A caller claiming to be from the police says your account is linked to a crime and your savings must be moved to a government safe account. What is happening?",
        "options": [
            "A legitimate emergency procedure, so move the money quickly",
            "A scam — no such account exists",
            "A legitimate request, but only if they give a case number",
            "A bank procedure that the police carry out on your behalf",
        ],
        "answer": 1,
        "explanation": (
            "There is no such thing as a government safe account. The Singapore Police Force "
            "never asks anyone to transfer money for safekeeping, and no case number or uniform "
            "on a video call changes that."
        ),
    },
    {
        "id": "qr-receive",
        "prompt": "A buyer on Carousell sends you a QR code and says scanning it will send you their payment. Is that how it works?",
        "options": [
            "Yes, QR codes work in both directions",
            "Yes, as long as the app shows the buyer's name",
            "No — scanning a payment QR code sends money, it never receives it",
            "No, but it is safe as long as the amount shows zero",
        ],
        "answer": 2,
        "explanation": (
            "You scan a QR code to pay, never to be paid. To receive money you give someone your "
            "number or your own QR. Anyone insisting you scan theirs is trying to get you to "
            "authorise a transfer out."
        ),
    },
    {
        "id": "spf-dkim",
        "prompt": "An email passes both SPF and DKIM. What does that actually prove?",
        "options": [
            "The message is safe to act on",
            "The links inside it have been checked",
            "It genuinely came from the domain it claims, though it may still be unwanted",
            "A human at the company reviewed it before sending",
        ],
        "answer": 2,
        "explanation": (
            "SPF and DKIM authenticate the sending domain, nothing more. A scammer who registers "
            "dbs-secure-verify.co can pass both checks perfectly, because they really do own that "
            "domain. Authentication tells you who sent it, not whether to trust it."
        ),
    },
    {
        "id": "personal-details",
        "prompt": "A text knows your full name and the last three digits of your NRIC. Does that mean it is genuine?",
        "options": [
            "Yes, only a real organisation would have those details",
            "No — personal details leak constantly and are cheap to buy",
            "Yes, if it also uses the correct company logo",
            "Only if it arrives from a short code rather than a mobile number",
        ],
        "answer": 1,
        "explanation": (
            "Breached databases are traded in bulk, so knowing your details costs a scammer "
            "almost nothing. Personalisation is a persuasion technique, not proof of identity. "
            "Logos and sender IDs are equally easy to copy."
        ),
    },
    {
        "id": "job-deposit",
        "prompt": "A Telegram message offers S$400 a day for liking videos, with a small deposit needed to unlock higher-paying tasks. What is the tell?",
        "options": [
            "The pay is quoted per day rather than per hour",
            "It arrived on Telegram rather than by email",
            "Real work never requires you to pay money in first",
            "There is no interview",
        ],
        "answer": 2,
        "explanation": (
            "Employment pays you. The moment a job asks you to deposit, top up, or unlock, it has "
            "become an advance-fee scam. Early small payouts exist to build confidence before a "
            "larger deposit is requested."
        ),
    },
    {
        "id": "unrequested-otp",
        "prompt": "A verification code arrives for an account you did not just try to log in to. What does that tell you?",
        "options": [
            "It is a harmless glitch",
            "Someone likely has your password and is trying to get past the second step",
            "Your phone number has been reassigned",
            "The service is testing its systems",
        ],
        "answer": 1,
        "explanation": (
            "An unrequested code usually means someone has already entered a working password and "
            "is stuck at the second factor. Never pass the code on, and change that password now, "
            "along with any other account sharing it."
        ),
    },
    {
        "id": "double-extension",
        "prompt": "An email attachment is named invoice.pdf.exe. What is it?",
        "options": [
            "A PDF that opens in a special reader",
            "A compressed PDF",
            "A program, disguised to look like a document",
            "A corrupted file",
        ],
        "answer": 2,
        "explanation": (
            "Only the final extension counts, so this is an executable. Windows hides known "
            "extensions by default, which is exactly why the trick works — the file appears in "
            "the inbox as 'invoice.pdf'."
        ),
    },
    {
        "id": "new-number",
        "prompt": "You get a message: \"Hi Mum, my phone broke, this is my new number. Can you PayNow me urgently?\" What is the right move?",
        "options": [
            "Transfer the money, since the message knows who you are",
            "Ask a personal question only your child would know",
            "Call the old number, or someone who has seen them recently",
            "Send a smaller amount as a test",
        ],
        "answer": 2,
        "explanation": (
            "Calling the number you already had is the check that works. A personal question is "
            "weaker than it feels, because answers are often findable on social media, and a "
            "test transfer just confirms to the scammer that the line is live."
        ),
    },
    {
        "id": "guaranteed-returns",
        "prompt": "An investment group promises guaranteed returns of 300% within 24 hours. What is wrong with that?",
        "options": [
            "The returns are taxable",
            "No legitimate investment can guarantee a return at all",
            "24 hours is too short a window for a transfer to clear",
            "Nothing, if the platform is regulated overseas",
        ],
        "answer": 1,
        "explanation": (
            "Return always carries risk, so a guarantee is the giveaway regardless of the "
            "percentage. Withdrawals typically work at first and then require a 'tax' or "
            "'unlocking fee' once a larger sum is deposited."
        ),
    },
    {
        "id": "urgency",
        "prompt": "Why do scam messages so often insist you act within the hour?",
        "options": [
            "Automated systems really do expire quickly",
            "Time pressure stops you checking with anyone else",
            "It helps the message get past spam filters",
            "It is a legal requirement for account notices",
        ],
        "answer": 1,
        "explanation": (
            "Urgency is the point of the whole message. Checking with a bank, a colleague, or a "
            "family member is what breaks the scam, so the script exists to make sure you never "
            "get that far. Genuine organisations let you take your time."
        ),
    },
    {
        "id": "remote-access",
        "prompt": "A caller offering to fix a billing problem asks you to install AnyDesk so they can help. What does that give them?",
        "options": [
            "A read-only view of the error message",
            "Nothing, it only shares a screenshot",
            "Full control of your device, including your banking apps",
            "Access to the app they are helping with, and no others",
        ],
        "answer": 2,
        "explanation": (
            "Remote access tools hand over the whole machine, not one window. Once connected, "
            "someone can open your banking app, read incoming codes, and move money while the "
            "screen shows something harmless."
        ),
    },
    {
        "id": "reporting",
        "prompt": "You think you have just been scammed in Singapore. What should you do first?",
        "options": [
            "Wait a few days to see whether the money comes back",
            "Reply to the scammer and ask for a refund",
            "Call your bank to freeze the account, then report it",
            "Post the details publicly to warn others",
        ],
        "answer": 2,
        "explanation": (
            "Speed decides whether funds can be held. Contact your bank immediately, then make a "
            "police report. The ScamShield helpline on 1799 can advise. Warning others is worth "
            "doing, but only after the money is dealt with."
        ),
    },
]

BY_ID = {question["id"]: question for question in QUESTION_BANK}
ROUND_SIZE = 5


def public_question(question: dict[str, Any]) -> dict[str, Any]:
    """The question as the browser sees it, with the answer stripped out."""
    return {
        "id": question["id"],
        "prompt": question["prompt"],
        "options": question["options"],
    }


def new_round(count: int = ROUND_SIZE) -> list[dict[str, Any]]:
    count = max(1, min(count, len(QUESTION_BANK)))
    return [public_question(q) for q in random.sample(QUESTION_BANK, count)]


def grade(question_id: str, choice: int) -> dict[str, Any] | None:
    """Mark one answer. Returns None when the question id is unknown."""
    question = BY_ID.get(question_id)
    if question is None:
        return None
    return {
        "correct": choice == question["answer"],
        "answer": question["answer"],
        "explanation": question["explanation"],
    }


def verdict_for(score: int, total: int) -> tuple[str, str]:
    """A headline and a line of feedback for a finished round."""
    share = score / total if total else 0
    if share == 1:
        return ("Full marks.", "You spotted every one. Keep the same scepticism when a message is about your own money.")
    if share >= 0.8:
        return ("Sharp eye.", "You would catch most of these in the wild. The ones you missed are worth rereading.")
    if share >= 0.6:
        return ("Solid instincts.", "Your gut is mostly right. Tighten up on the details, since scams are built to exploit exactly those gaps.")
    if share >= 0.4:
        return ("Worth another look.", "Several of these would have caught you. Read the explanations, then try a fresh set.")
    return ("Take your time with these.", "Most of these got past you, which is exactly how scams work. The explanations are the useful part.")
