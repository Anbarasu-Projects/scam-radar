"""Flask API for Scam Radar."""
from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

from analysis import analyze_extraction
from extractors import audio as audio_extractor
from extractors import documents as document_extractor
from extractors import email_forensics
from extractors.base import ExtractionError
import quiz
from model import get_detector

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent
FRONTEND_DIST = PROJECT_DIR / "frontend" / "dist"
DB_PATH = Path(os.getenv("SCAMSHIELD_DB", BASE_DIR / "scamshield.db"))
MAX_MESSAGE_LENGTH = 5000
MAX_UPLOAD_BYTES = 16 * 1024 * 1024

# Flask serves both the JSON API and the compiled React site in production.
app = Flask(__name__, static_folder=None)
app.config["JSON_SORT_KEYS"] = False
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
CORS(app, resources={r"/api/*": {"origins": os.getenv("FRONTEND_ORIGIN", "*")}})


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with closing(get_db()) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                verdict TEXT NOT NULL,
                confidence REAL NOT NULL,
                scam_probability REAL NOT NULL,
                risk_level TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        # Databases created before the multi-input release lack these columns.
        existing = {row["name"] for row in conn.execute("PRAGMA table_info(scans)")}
        if "source" not in existing:
            conn.execute("ALTER TABLE scans ADD COLUMN source TEXT NOT NULL DEFAULT 'text'")
        if "origin" not in existing:
            conn.execute("ALTER TABLE scans ADD COLUMN origin TEXT")
        conn.commit()


def serialize_scan(row: sqlite3.Row) -> dict:
    keys = row.keys()
    return {
        "id": row["id"],
        "message": row["message"],
        "verdict": row["verdict"],
        "confidence": row["confidence"],
        "scam_probability": row["scam_probability"],
        "risk_level": row["risk_level"],
        "created_at": row["created_at"],
        "source": row["source"] if "source" in keys else "text",
        "origin": row["origin"] if "origin" in keys else None,
    }


def save_scan(message: str, result: dict, source: str = "text", origin: str | None = None) -> dict:
    """Persist one scan and stamp the result with its id and timestamp."""
    created_at = datetime.now(timezone.utc).isoformat()
    stored = message[:MAX_MESSAGE_LENGTH]
    with closing(get_db()) as conn:
        cursor = conn.execute(
            """
            INSERT INTO scans
                (message, verdict, confidence, scam_probability, risk_level, created_at, source, origin)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                stored,
                result["verdict"],
                result["confidence"],
                result["scam_probability"],
                result["risk_level"],
                created_at,
                source,
                origin,
            ),
        )
        conn.commit()
        result["id"] = cursor.lastrowid
    result["message"] = stored
    result["created_at"] = created_at
    result["source"] = source
    result["origin"] = origin
    return result


def read_upload(field: str = "file"):
    """Pull an uploaded file off the request, or raise a user-facing error."""
    uploaded = request.files.get(field)
    if uploaded is None or not uploaded.filename:
        raise ExtractionError("No file was uploaded.")
    data = uploaded.read()
    if not data:
        raise ExtractionError("The uploaded file was empty.")
    return uploaded.filename, data


@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Hugging Face displays Spaces inside an iframe, so allow only HF and self.
    response.headers["Content-Security-Policy"] = (
        "frame-ancestors 'self' https://huggingface.co https://*.huggingface.co"
    )
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Scam Radar", "model": "TF-IDF + Logistic Regression"})


@app.post("/api/analyze")
def analyze():
    payload = request.get_json(silent=True) or {}
    message = str(payload.get("message", "")).strip()

    if not message:
        return jsonify({"error": "Please enter a message to analyze."}), 400
    if len(message) < 4:
        return jsonify({"error": "The message is too short to analyze reliably."}), 400
    if len(message) > MAX_MESSAGE_LENGTH:
        return jsonify({"error": f"Message must be under {MAX_MESSAGE_LENGTH} characters."}), 400

    result = get_detector().analyze(message)
    return jsonify(save_scan(message, result, source="text")), 201


@app.get("/api/quiz")
def quiz_round():
    """Five questions, without their answers."""
    try:
        count = int(request.args.get("count", quiz.ROUND_SIZE))
    except ValueError:
        count = quiz.ROUND_SIZE
    questions = quiz.new_round(count)
    return jsonify({"questions": questions, "total": len(questions)})


@app.post("/api/quiz/answer")
def quiz_answer():
    """Mark a single answer and return the explanation behind it."""
    payload = request.get_json(silent=True) or {}
    question_id = str(payload.get("id", ""))
    try:
        choice = int(payload.get("choice"))
    except (TypeError, ValueError):
        return jsonify({"error": "Pick an option before submitting."}), 400

    marked = quiz.grade(question_id, choice)
    if marked is None:
        return jsonify({"error": "That question is not in the current bank."}), 404
    return jsonify(marked)


@app.post("/api/quiz/result")
def quiz_result():
    """Turn a finished round into a headline and a line of feedback."""
    payload = request.get_json(silent=True) or {}
    try:
        score = int(payload.get("score", 0))
        total = int(payload.get("total", quiz.ROUND_SIZE))
    except (TypeError, ValueError):
        return jsonify({"error": "Score and total must be whole numbers."}), 400
    if total <= 0 or not 0 <= score <= total:
        return jsonify({"error": "That score does not fit the round."}), 400

    headline, note = quiz.verdict_for(score, total)
    return jsonify({"score": score, "total": total, "headline": headline, "note": note})


@app.get("/api/capabilities")
def capabilities():
    """Tell the frontend which optional readers this server actually has."""
    docs = document_extractor.capabilities()
    voice = audio_extractor.capabilities()
    return jsonify({
        "text": True,
        "email": True,
        "document": {
            "pdf": docs["pdf"],
            "docx": docs["docx"],
            "image_ocr": docs["ocr"],
            "ocr_engine": docs["ocr_engine"],
            "plain_text": True,
        },
        "voice": {
            "server_transcription": voice["server_transcription"],
            "engine": voice["engine"],
            "browser_transcript": True,
        },
    })


@app.post("/api/analyze-email")
def analyze_email_route():
    """Analyze a raw email: headers, body, links, and attachments."""
    try:
        if request.files.get("file"):
            filename, data = read_upload()
            raw = data.decode("utf-8", errors="replace")
            origin = filename
        else:
            payload = request.get_json(silent=True) or {}
            raw = str(payload.get("raw") or payload.get("message") or "")
            origin = None
        extraction = email_forensics.extract_email(raw)
    except ExtractionError as exc:
        return jsonify({"error": str(exc)}), 400

    result = analyze_extraction(extraction)
    subject = extraction.meta.get("subject") or ""
    sender = extraction.meta.get("from") or "unknown sender"
    summary = f"[Email] {subject or '(no subject)'} — from {sender}"
    return jsonify(save_scan(summary, result, source="email", origin=origin or sender)), 201


@app.post("/api/analyze-file")
def analyze_file_route():
    """Analyze a PDF, DOCX, text file, or screenshot."""
    try:
        filename, data = read_upload()
        extraction = document_extractor.extract_document(filename, data)
    except ExtractionError as exc:
        return jsonify({"error": str(exc)}), 400

    result = analyze_extraction(extraction)
    snippet = extraction.text[:180].replace("\n", " ")
    summary = f"[{Path(filename).suffix.lstrip('.').upper() or 'FILE'}] {filename} — {snippet}"
    return jsonify(save_scan(summary, result, source="document", origin=filename)), 201


@app.post("/api/analyze-audio")
def analyze_audio_route():
    """Analyze a voice note, either transcribed here or in the browser."""
    try:
        if request.files.get("file"):
            filename, data = read_upload()
            extraction = audio_extractor.transcribe_audio(filename, data)
            origin = filename
        else:
            payload = request.get_json(silent=True) or {}
            extraction = audio_extractor.from_browser_transcript(str(payload.get("transcript", "")))
            origin = "browser recording"
    except ExtractionError as exc:
        return jsonify({"error": str(exc)}), 400

    result = analyze_extraction(extraction)
    transcript = extraction.meta.get("transcript", extraction.text)
    return jsonify(save_scan(f"[Voice] {transcript}", result, source="voice", origin=origin)), 201


@app.get("/api/history")
def history():
    try:
        limit = min(max(int(request.args.get("limit", 20)), 1), 100)
    except ValueError:
        limit = 20

    with closing(get_db()) as conn:
        rows = conn.execute(
            "SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        totals = conn.execute(
            """
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN verdict = 'SCAM' THEN 1 ELSE 0 END) AS scams
            FROM scans
            """
        ).fetchone()

    return jsonify({
        "items": [serialize_scan(row) for row in rows],
        "summary": {"total": totals["total"] or 0, "scams": totals["scams"] or 0},
    })


@app.delete("/api/history")
def clear_history():
    with closing(get_db()) as conn:
        conn.execute("DELETE FROM scans")
        conn.commit()
    return jsonify({"message": "History cleared."})


@app.delete("/api/history/<int:scan_id>")
def delete_scan(scan_id: int):
    with closing(get_db()) as conn:
        cursor = conn.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
        conn.commit()
    if cursor.rowcount == 0:
        return jsonify({"error": "Scan not found."}), 404
    return jsonify({"message": "Scan deleted."})


@app.get("/")
def serve_frontend():
    """Serve the compiled React entry page in Docker/production."""
    if not (FRONTEND_DIST / "index.html").is_file():
        return jsonify({
            "message": "Frontend build not found. Run npm run build in frontend/.",
            "api_health": "/api/health",
        }), 404
    return send_from_directory(FRONTEND_DIST, "index.html")


@app.get("/<path:asset_path>")
def serve_frontend_asset(asset_path: str):
    """Serve Vite assets and fall back to index.html for client routes."""
    if asset_path.startswith("api/"):
        return jsonify({"error": "Endpoint not found."}), 404

    requested_file = FRONTEND_DIST / asset_path
    if requested_file.is_file():
        return send_from_directory(FRONTEND_DIST, asset_path)
    if (FRONTEND_DIST / "index.html").is_file():
        return send_from_directory(FRONTEND_DIST, "index.html")
    return jsonify({"error": "Frontend build not found."}), 404


@app.errorhandler(413)
def payload_too_large(_error):
    return jsonify({"error": "That file is too large. The limit is 16 MB."}), 413


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Endpoint not found."}), 404


@app.errorhandler(500)
def server_error(_error):
    return jsonify({"error": "Something went wrong on the server."}), 500


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=os.getenv("FLASK_DEBUG") == "1")
