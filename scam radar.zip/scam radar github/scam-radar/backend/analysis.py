"""Combine the NLP verdict with forensic signals from the input extractors.

model.py judges wording. The extractors judge structure: email headers, PDF
JavaScript, disguised links. This module blends the two into one verdict while
keeping every signal visible, so the explanation stays honest.
"""
from __future__ import annotations

from typing import Any

from extractors.base import ExtractedSignal, ExtractionResult
from model import get_detector

# How much forensic evidence can move the verdict on its own. Capped so a single
# structural finding never fully overrides what the language model saw.
MAX_FORENSIC_LIFT = 0.45
MAX_FORENSIC_DROP = 0.20


def analyze_extraction(extraction: ExtractionResult) -> dict[str, Any]:
    """Run the detector over extracted text, then fold in forensic signals."""
    result = get_detector().analyze(extraction.text)

    risk_weight = sum(s.weight for s in extraction.signals if s.kind == "risk")
    safe_weight = sum(-s.weight for s in extraction.signals if s.kind == "safe")

    base = result["scam_probability"] / 100.0
    lift = min(MAX_FORENSIC_LIFT, risk_weight)
    drop = min(MAX_FORENSIC_DROP, safe_weight)

    # Soft OR: forensic evidence closes part of the gap to certainty rather than
    # being added on top, so probabilities never run past 1.
    blended = base + lift * (1.0 - base)
    blended = blended - drop * blended
    blended = max(0.02, min(0.98, blended))

    is_scam = blended >= 0.50
    result["scam_probability"] = round(blended * 100, 1)
    result["confidence"] = round((blended if is_scam else 1 - blended) * 100, 1)
    result["verdict"] = "SCAM" if is_scam else "LEGIT"
    result["risk_level"] = "High" if blended >= 0.72 else "Medium" if blended >= 0.45 else "Low"

    # Forensic findings lead, because they are the harder evidence.
    forensic = [s.as_dict() for s in _dedupe(extraction.signals)]
    language = [s for s in result["signals"] if s["label"] != "No common scam patterns"]
    result["signals"] = (forensic + language)[:8]
    if not result["signals"]:
        result["signals"] = [{
            "label": "No common scam patterns",
            "detail": "Nothing in the wording or the file structure matched a known scam pattern.",
            "kind": "safe",
        }]

    result["source"] = extraction.source
    result["meta"] = extraction.meta
    if extraction.warnings:
        result["warnings"] = extraction.warnings

    if is_scam:
        result["advice"] = _advice_for(extraction.source)
    return result


def _advice_for(source: str) -> str:
    return {
        "email": (
            "Do not click any link or open the attachments. Check the sender's real address, not the "
            "display name, and reach the organisation through a number you already had."
        ),
        "document": (
            "Do not open this file outside a sandbox, and do not enable macros or content prompts. "
            "Confirm with the sender through a channel you already trust."
        ),
        "voice": (
            "Hang up and call back on a number you looked up yourself. Real institutions never ask for "
            "an OTP, PIN, or remote access over a call."
        ),
    }.get(source, (
        "Do not reply, tap links, share credentials, or send money. Verify the sender using an "
        "official number or app."
    ))


def _dedupe(signals: list[ExtractedSignal]) -> list[ExtractedSignal]:
    seen: set[str] = set()
    unique: list[ExtractedSignal] = []
    for signal in sorted(signals, key=lambda s: -abs(s.weight)):
        if signal.label in seen:
            continue
        seen.add(signal.label)
        unique.append(signal)
    return unique[:6]
