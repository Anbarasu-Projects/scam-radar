"""Shared types for every extractor."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExtractedSignal:
    """A forensic finding that the text classifier alone could not see.

    `weight` is a 0-1 contribution to the scam probability. `kind` is either
    "risk" or "safe" so the existing React result card can colour it.
    """

    label: str
    detail: str
    weight: float
    kind: str = "risk"

    def as_dict(self) -> dict[str, Any]:
        return {"label": self.label, "detail": self.detail, "kind": self.kind}


@dataclass
class ExtractionResult:
    """Text pulled out of an input, plus metadata and forensic signals."""

    text: str
    source: str
    meta: dict[str, Any] = field(default_factory=dict)
    signals: list[ExtractedSignal] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class ExtractionError(Exception):
    """Raised when an input cannot be read at all. Message is user-facing."""
