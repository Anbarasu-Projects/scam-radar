"""Reading text out of a screenshot, with no manual setup.

Three engines are tried in order. The first one that works wins:

1. `winocr` — the OCR built into Windows 10/11. Pip-installable, no separate
   download, and it keeps word spacing correctly.
2. `pytesseract` — only if someone has already installed the Tesseract engine.
3. `rapidocr-onnxruntime` — pure pip, ships its models inside the wheel, and
   runs anywhere. Its bundled recognition model does not emit spaces on Latin
   text, so `repair_spacing` puts them back.

Because option 3 installs from `requirements.txt` like any other package, a
plain `pip install -r requirements.txt` leaves screenshot reading working. The
first two are quality upgrades, not requirements.
"""
from __future__ import annotations

import functools
import io
import re

_MIN_RUN = 12  # A word this long with no space in it is almost certainly glued.


def available_engine() -> str | None:
    """Name of the first usable OCR engine, or None."""
    for name, probe in (("winocr", _has_winocr), ("tesseract", _has_tesseract), ("rapidocr", _has_rapidocr)):
        if probe():
            return name
    return None


def _has_winocr() -> bool:
    try:
        import winocr  # noqa: F401
        return True
    except Exception:
        return False


def _has_tesseract() -> bool:
    try:
        import pytesseract
        _configure_tesseract(pytesseract)
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def _has_rapidocr() -> bool:
    try:
        from rapidocr_onnxruntime import RapidOCR  # noqa: F401
        return True
    except Exception:
        return False


def _configure_tesseract(pytesseract) -> None:
    """Windows installers often skip PATH, so check the usual locations too."""
    import os
    import shutil

    for candidate in (
        os.getenv("SCAMSHIELD_TESSERACT_CMD"),
        shutil.which("tesseract"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ):
        if candidate and os.path.isfile(candidate):
            pytesseract.pytesseract.tesseract_cmd = candidate
            return


@functools.lru_cache(maxsize=1)
def _rapid_engine():
    from rapidocr_onnxruntime import RapidOCR
    return RapidOCR()


@functools.lru_cache(maxsize=1)
def _lexicon() -> frozenset[str]:
    """Words used to put spacing back into glued OCR output.

    Built from the project's own training corpus, so it already contains the
    vocabulary that matters here, plus common English filler.
    """
    from model import LEGIT_MESSAGES, SCAM_MESSAGES

    words = set()
    for message in SCAM_MESSAGES + LEGIT_MESSAGES:
        for token in re.findall(r"[a-z]+", message.lower()):
            if len(token) > 1:
                words.add(token)
    words.update("""
        a an and are as at be been before but by call called can click confirm
        contact do does for from get go has have here how if in is it its just
        link linked links me my new no not now of on once one only or our out
        over please reply see send sent share should so some tell than that the
        their them then there these they this to today up us use used using very
        via want was we were what when which who will with within you your yours
        account accounts alert alerts bank banking blocked cancel card cards
        case charge charges claim click code codes confirm credit customer
        delivery detail details expire expired expires fee fees final free
        immediately important last locked login logon message notice number
        offer offers otp parcel password pay payment penalty pin prize
        processing refund register reward scan secure security service suspend
        suspended transfer unpaid update urgent verify verification warning win
        won http https www com sg net org
    """.split())
    return frozenset(words)


def repair_spacing(text: str) -> str:
    """Split glued runs like 'YourDBSaccountislocked' back into words."""
    words = _lexicon()

    def split_run(run: str) -> str:
        lowered = run.lower()
        n = len(lowered)
        # best[i] = (word count, split points) for the prefix of length i.
        best: list[tuple[int, list[int]] | None] = [(0, [])] + [None] * n
        for end in range(1, n + 1):
            for start in range(max(0, end - 18), end):
                prior = best[start]
                if prior is None:
                    continue
                piece = lowered[start:end]
                if len(piece) > 1 and piece in words:
                    candidate = (prior[0] + 1, prior[1] + [end])
                    if best[end] is None or candidate[0] < best[end][0]:
                        best[end] = candidate
        if best[n] is None:
            return run
        pieces, previous = [], 0
        for point in best[n][1]:
            pieces.append(run[previous:point])
            previous = point
        return " ".join(pieces)

    def replace(match: re.Match) -> str:
        return split_run(match.group(0))

    # Only touch long alphabetic runs; leave URLs, numbers and codes alone.
    return re.sub(rf"[A-Za-z]{{{_MIN_RUN},}}", replace, text)


def read_image(data: bytes) -> tuple[str, str]:
    """Return (text, engine_name). Raises RuntimeError if no engine works."""
    engine = available_engine()
    if engine is None:
        raise RuntimeError(
            "No OCR engine is installed. Run: pip install rapidocr-onnxruntime"
        )
    if engine == "winocr":
        return _read_winocr(data), "Windows OCR"
    if engine == "tesseract":
        return _read_tesseract(data), "Tesseract"
    return _read_rapidocr(data), "RapidOCR"


def _read_winocr(data: bytes) -> str:
    import winocr
    from PIL import Image

    image = Image.open(io.BytesIO(data)).convert("RGB")
    result = winocr.recognize_pil_sync(image, "en-US")
    return (result.text or "").strip()


def _read_tesseract(data: bytes) -> str:
    import pytesseract
    from PIL import Image

    _configure_tesseract(pytesseract)
    image = Image.open(io.BytesIO(data))
    return (pytesseract.image_to_string(image) or "").strip()


def _read_rapidocr(data: bytes) -> str:
    import numpy as np
    from PIL import Image

    image = Image.open(io.BytesIO(data)).convert("RGB")
    result, _elapsed = _rapid_engine()(np.array(image))
    if not result:
        return ""
    lines = [str(item[1]) for item in result]
    return repair_spacing("\n".join(lines)).strip()
