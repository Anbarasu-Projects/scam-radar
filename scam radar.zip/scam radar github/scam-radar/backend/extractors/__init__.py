"""Input extractors that turn documents, emails, and audio into analyzable text.

Each extractor returns an ExtractionResult so app.py can treat every input type
the same way: pull out `text`, hand it to the NLP detector, and merge any
forensic `signals` the extractor found along the way.
"""
from .base import ExtractionResult, ExtractedSignal

__all__ = ["ExtractionResult", "ExtractedSignal"]
