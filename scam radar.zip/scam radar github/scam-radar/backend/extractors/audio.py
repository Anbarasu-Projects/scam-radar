"""Voice input: transcribe a recording, then judge the transcript.

Two paths, because speech-to-text is the one part of this project that cannot
run everywhere:

1. Server-side `faster-whisper` if it is installed. Accurate, fully offline,
   but heavy (a few hundred MB) and slow on a CPU-only free host.
2. Browser transcript. The React app can use the Web Speech API and post the
   text it heard, so the demo still works with zero extra dependencies.

The API accepts either. `capabilities()` tells the frontend which to offer.
"""
from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path

from .base import ExtractedSignal, ExtractionError, ExtractionResult

# Patterns that only make sense on a live call. The text classifier was trained
# on written messages, so these catch what it was never shown.
VISHING_PATTERNS = [
    (r"\b(do not|don'?t) (hang up|disconnect|cut the call)\b",
     "Told not to hang up",
     "Keeping you on the line stops you from calling the real organisation to check.", 0.30),
    (r"\b(press|dial) (one|two|1|2|9)\b",
     "Phone-tree redirect",
     "Asks you to press a key to be transferred, a standard way to route victims to a live scammer.", 0.18),
    (r"\b(stay on the line|remain on the call|keep me on the phone)\b",
     "Pressure to stay on the call",
     "Isolating you for the length of the call is a control tactic.", 0.24),
    (r"\b(read|tell|share|give) (me |us )?(the |your )?(otp|code|pin|password|cvv)\b",
     "Asked to read out a code",
     "No bank, delivery service, or government office ever asks for a code over the phone.", 0.38),
    (r"\b(i am|this is|calling from)[^.]{0,40}\b(bank|police|cyber|customs|court|department|officer|inspector)\b",
     "Claims official authority",
     "Impersonating an authority figure by voice is easy and cannot be verified on the call itself.", 0.22),
    (r"\b(anydesk|teamviewer|quick ?support|screen ?shar|install (the |this )?app)\b",
     "Remote access request",
     "Installing this hands control of your device to the caller.", 0.34),
    (r"\b(warrant|arrest|police report|case (has been )?(filed|registered)|legal action|nric)\b",
     "Threat of arrest",
     "The Singapore Police Force does not resolve cases or demand payment over an unsolicited call.", 0.26),
    (r"\b(gift card|google play|amazon voucher|steam card|safe(ty)? account)\b",
     "Gift card payment",
     "No agency asks you to buy gift cards or move savings into a \"safe account\". Both are pure scam scripts.", 0.36),
]


def transcript_signals(text: str) -> list[ExtractedSignal]:
    """Call-specific red flags found in a transcript."""
    found: list[ExtractedSignal] = []
    for pattern, label, detail, weight in VISHING_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            found.append(ExtractedSignal(label, detail, weight))
    return found

AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".ogg", ".webm", ".flac", ".aac", ".mp4"}
MAX_AUDIO_BYTES = 15 * 1024 * 1024

WHISPER_MODEL_SIZE = os.getenv("SCAMSHIELD_WHISPER_MODEL", "tiny")

_model = None


def capabilities() -> dict[str, object]:
    try:
        import faster_whisper  # noqa: F401
        return {"server_transcription": True, "engine": f"faster-whisper ({WHISPER_MODEL_SIZE})"}
    except ImportError:
        return {"server_transcription": False, "engine": None}


def _get_model():
    """Load Whisper once, lazily. The first call downloads the model."""
    global _model
    if _model is None:
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise ExtractionError(
                "Server-side transcription is not installed. Run: pip install faster-whisper, "
                "or use the browser's live transcription instead."
            ) from exc
        _model = WhisperModel(WHISPER_MODEL_SIZE, device="cpu", compute_type="int8")
    return _model


def transcribe_audio(filename: str, data: bytes) -> ExtractionResult:
    suffix = Path(filename or "").suffix.lower()
    if suffix and suffix not in AUDIO_EXTENSIONS:
        raise ExtractionError(
            f"'{suffix}' is not a supported audio format. Use WAV, MP3, M4A, OGG, or WEBM."
        )
    if len(data) > MAX_AUDIO_BYTES:
        raise ExtractionError("That recording is larger than 15 MB. Trim it and try again.")
    if not data:
        raise ExtractionError("The recording was empty.")

    model = _get_model()

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix or ".wav", delete=False) as tmp:
            tmp.write(data)
            tmp_path = tmp.name
        segments, info = model.transcribe(tmp_path, beam_size=1, vad_filter=True)
        text = " ".join(segment.text.strip() for segment in segments).strip()
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError(
            "The recording could not be transcribed. FFmpeg may be missing from your system."
        ) from exc
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    if not text:
        raise ExtractionError("No speech was detected in that recording.")

    signals = transcript_signals(text)
    language = getattr(info, "language", None)
    duration = round(float(getattr(info, "duration", 0.0)), 1)

    meta = {
        "filename": filename,
        "duration_seconds": duration,
        "language": language,
        "engine": f"faster-whisper ({WHISPER_MODEL_SIZE})",
        "transcript": text,
    }
    return ExtractionResult(text=text, source="voice", meta=meta, signals=signals)


def from_browser_transcript(text: str) -> ExtractionResult:
    """Accept a transcript the browser produced with the Web Speech API."""
    cleaned = (text or "").strip()
    if len(cleaned) < 4:
        raise ExtractionError("The transcript was too short to analyze. Try speaking for longer.")
    return ExtractionResult(
        text=cleaned[:5000],
        source="voice",
        meta={"engine": "browser Web Speech API", "transcript": cleaned},
        signals=transcript_signals(cleaned),
    )
