"""Turn an uploaded document or screenshot into text the detector can read.

Supported: .pdf, .docx, .txt/.md/.csv, and images (.png/.jpg/.webp) when
Tesseract OCR is available. Every heavy dependency is imported lazily so the
app still starts with only the base requirements installed.
"""
from __future__ import annotations

import io
import re
from pathlib import Path

from . import ocr
from .base import ExtractedSignal, ExtractionError, ExtractionResult

TEXT_EXTENSIONS = {".txt", ".md", ".csv", ".log"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff"}
DOC_EXTENSIONS = {".pdf", ".docx"} | TEXT_EXTENSIONS | IMAGE_EXTENSIONS

MAX_EXTRACTED_CHARS = 20000

# Extensions that should never arrive as an attachment from a stranger.
DANGEROUS_ATTACHMENT_EXTENSIONS = {
    ".exe", ".apk", ".scr", ".bat", ".cmd", ".com", ".pif", ".vbs",
    ".js", ".jar", ".msi", ".ps1", ".hta", ".iso", ".img",
}


def capabilities() -> dict[str, object]:
    """Report which readers are installed, for /api/capabilities."""
    caps: dict[str, object] = {"pdf": False, "docx": False, "ocr": False, "ocr_engine": None, "text": True}
    try:
        import pypdf  # noqa: F401
        caps["pdf"] = True
    except ImportError:
        pass
    try:
        import docx  # noqa: F401
        caps["docx"] = True
    except ImportError:
        pass
    engine = ocr.available_engine()
    caps["ocr"] = engine is not None
    caps["ocr_engine"] = {"winocr": "Windows OCR", "tesseract": "Tesseract", "rapidocr": "RapidOCR"}.get(engine)
    return caps


def _clean(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _read_pdf(data: bytes) -> tuple[str, dict, list[ExtractedSignal]]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ExtractionError(
            "PDF support is not installed on the server. Run: pip install pypdf"
        ) from exc

    signals: list[ExtractedSignal] = []
    try:
        reader = PdfReader(io.BytesIO(data))
    except Exception as exc:
        raise ExtractionError("That PDF could not be opened. It may be corrupt or password protected.") from exc

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:
            raise ExtractionError("That PDF is password protected, so its text cannot be read.") from exc

    pages = []
    for page in reader.pages[:40]:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            continue
    text = _clean("\n".join(pages))

    # Forensic layer: things a text classifier can never see.
    raw = data[:2_000_000]
    if b"/JavaScript" in raw or b"/JS" in raw:
        signals.append(ExtractedSignal(
            "PDF contains JavaScript",
            "This PDF embeds executable script. Invoices and receipts almost never need it.",
            0.30,
        ))
    if b"/OpenAction" in raw or b"/AA" in raw:
        signals.append(ExtractedSignal(
            "PDF auto-runs an action",
            "The file is set to trigger something the moment it opens, a common malware delivery trick.",
            0.24,
        ))
    if b"/Launch" in raw or b"/EmbeddedFile" in raw:
        signals.append(ExtractedSignal(
            "PDF embeds or launches a file",
            "The document carries another file inside it rather than just being a document.",
            0.26,
        ))

    link_domains = _annotation_links(reader)
    if link_domains:
        signals.extend(_link_signals(link_domains))

    if not text:
        signals.append(ExtractedSignal(
            "No readable text layer",
            "This PDF is a scan or image export, so wording could not be checked. Judge it on the sender instead.",
            0.05,
            "safe",
        ))

    meta = {"pages": len(reader.pages), "linked_domains": sorted(link_domains)[:10]}
    return text, meta, signals


def _annotation_links(reader) -> set[str]:
    """Pull URLs out of PDF link annotations, not just the visible text."""
    domains: set[str] = set()
    for page in reader.pages[:40]:
        try:
            annots = page.get("/Annots") or []
            for annot in annots:
                obj = annot.get_object()
                action = obj.get("/A") or {}
                uri = action.get("/URI")
                if uri:
                    host = _host_of(str(uri))
                    if host:
                        domains.add(host)
        except Exception:
            continue
    return domains


def _host_of(url: str) -> str:
    match = re.match(r"https?://([^/\s:]+)", url.strip(), re.IGNORECASE)
    return match.group(1).lower() if match else ""


SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "rebrand.ly", "cutt.ly", "shorturl.at", "rb.gy", "t.me", "tiny.cc",
}


def _link_signals(domains: set[str]) -> list[ExtractedSignal]:
    signals: list[ExtractedSignal] = []
    shortened = sorted(d for d in domains if d in SHORTENERS)
    if shortened:
        signals.append(ExtractedSignal(
            "Shortened link",
            f"Links hide their real destination behind {', '.join(shortened[:3])}.",
            0.20,
        ))
    raw_ip = sorted(d for d in domains if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", d))
    if raw_ip:
        signals.append(ExtractedSignal(
            "Link points to a raw IP address",
            f"Real companies use domain names, not addresses like {raw_ip[0]}.",
            0.28,
        ))
    punycode = sorted(d for d in domains if d.startswith("xn--") or ".xn--" in d)
    if punycode:
        signals.append(ExtractedSignal(
            "Lookalike domain characters",
            "A link uses punycode, which can disguise foreign characters as ordinary letters.",
            0.30,
        ))
    return signals


def _read_docx(data: bytes) -> tuple[str, dict, list[ExtractedSignal]]:
    try:
        import docx
    except ImportError as exc:
        raise ExtractionError(
            "Word support is not installed on the server. Run: pip install python-docx"
        ) from exc

    try:
        document = docx.Document(io.BytesIO(data))
    except Exception as exc:
        raise ExtractionError("That Word file could not be opened. It may be a .doc rather than a .docx.") from exc

    parts = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            parts.append(" | ".join(cell.text for cell in row.cells))

    signals: list[ExtractedSignal] = []
    if b"vbaProject.bin" in data:
        signals.append(ExtractedSignal(
            "Document contains macros",
            "Macro code is embedded in this file. This is the classic way malware arrives in a Word attachment.",
            0.34,
        ))

    domains = set()
    for rel in document.part.rels.values():
        if rel.reltype.endswith("/hyperlink"):
            host = _host_of(str(rel.target_ref))
            if host:
                domains.add(host)
    signals.extend(_link_signals(domains))

    meta = {"paragraphs": len(document.paragraphs), "linked_domains": sorted(domains)[:10]}
    return _clean("\n".join(parts)), meta, signals


def _read_image(data: bytes, filename: str) -> tuple[str, dict, list[ExtractedSignal]]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise ExtractionError(
            "Screenshot reading needs Pillow. Run: pip install -r requirements.txt"
        ) from exc

    try:
        image = Image.open(io.BytesIO(data))
        image.load()
    except Exception as exc:
        raise ExtractionError("That image could not be opened.") from exc

    try:
        text, engine = ocr.read_image(data)
    except RuntimeError as exc:
        raise ExtractionError(str(exc)) from exc
    except Exception as exc:
        raise ExtractionError("The screenshot could not be read. Try a sharper or larger crop.") from exc

    if not _clean(text):
        raise ExtractionError(
            "No text was found in that screenshot. Try a sharper crop, or one with larger text."
        )

    meta = {"width": image.width, "height": image.height, "format": image.format, "ocr_engine": engine}
    return _clean(text), meta, []


def extract_document(filename: str, data: bytes) -> ExtractionResult:
    """Dispatch on file extension and return text plus forensic signals."""
    suffix = Path(filename or "").suffix.lower()

    if suffix in DANGEROUS_ATTACHMENT_EXTENSIONS:
        raise ExtractionError(
            f"'{suffix}' files are executable, not documents. Scam Radar will not open one. "
            "If a stranger sent you this, that alone is a strong scam signal."
        )

    if suffix == ".pdf":
        text, meta, signals = _read_pdf(data)
    elif suffix == ".docx":
        text, meta, signals = _read_docx(data)
    elif suffix in IMAGE_EXTENSIONS:
        text, meta, signals = _read_image(data, filename)
    elif suffix in TEXT_EXTENSIONS or not suffix:
        text = _clean(data.decode("utf-8", errors="replace"))
        meta, signals = {}, []
    else:
        raise ExtractionError(
            f"'{suffix or 'that file type'}' is not supported. Upload a PDF, DOCX, TXT, or screenshot."
        )

    if not text:
        raise ExtractionError("No readable text was found in that file.")

    truncated = len(text) > MAX_EXTRACTED_CHARS
    warnings = []
    if truncated:
        text = text[:MAX_EXTRACTED_CHARS]
        warnings.append("Only the first 20,000 characters were analyzed.")

    meta["filename"] = filename
    meta["bytes"] = len(data)
    return ExtractionResult(
        text=text,
        source="document",
        meta=meta,
        signals=signals,
        warnings=warnings,
    )
