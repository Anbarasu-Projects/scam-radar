"""Email forensics: read headers the way an analyst would.

The text classifier judges wording. This module judges the envelope, which is
where phishing usually gives itself away regardless of how polished the prose
is: a Reply-To that redirects to a different domain, a display name claiming to
be a bank from a Gmail address, failed SPF or DKIM, or link text whose visible
domain does not match its href.

Everything here runs offline using Python's standard library.
"""
from __future__ import annotations

import email
import re
from email import policy
from email.message import EmailMessage
from email.utils import getaddresses, parseaddr

from .base import ExtractedSignal, ExtractionError, ExtractionResult
from .documents import DANGEROUS_ATTACHMENT_EXTENSIONS, SHORTENERS, _host_of

FREEMAIL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.in", "outlook.com",
    "hotmail.com", "live.com", "aol.com", "proton.me", "protonmail.com",
    "mail.com", "yandex.com", "zoho.com", "icloud.com",
    "gmx.com", "inbox.lv", "tutanota.com",
}

# Brand tokens commonly impersonated, with the domains that legitimately own them.
BRAND_DOMAINS = {
    "paypal": {"paypal.com", "paypal.com.sg"},
    "amazon": {"amazon.com", "amazon.sg"},
    "netflix": {"netflix.com"},
    "apple": {"apple.com", "icloud.com"},
    "microsoft": {"microsoft.com", "outlook.com", "office.com", "live.com"},
    "google": {"google.com", "gmail.com", "googlemail.com"},
    "facebook": {"facebook.com", "facebookmail.com", "meta.com"},
    "instagram": {"instagram.com", "mail.instagram.com"},
    "whatsapp": {"whatsapp.com", "support.whatsapp.com"},
    "linkedin": {"linkedin.com"},
    "dhl": {"dhl.com", "dhl.com.sg"},
    "fedex": {"fedex.com"},
    # Singapore banks and payment services.
    "dbs": {"dbs.com", "dbs.com.sg"},
    "posb": {"posb.com.sg", "dbs.com.sg"},
    "ocbc": {"ocbc.com", "ocbc.com.sg"},
    "uob": {"uob.com.sg", "uobgroup.com"},
    "maybank": {"maybank2u.com.sg", "maybank.com"},
    "standard chartered": {"sc.com"},
    "trust bank": {"trustbank.sg"},
    "paynow": {"abs.org.sg", "paynow.com.sg"},
    "grab": {"grab.com", "grabpay.com"},
    # Singapore government and public services.
    "singpass": {"singpass.gov.sg", "ndi-api.gov.sg"},
    "iras": {"iras.gov.sg"},
    "cpf": {"cpf.gov.sg"},
    "mom": {"mom.gov.sg"},
    "ica": {"ica.gov.sg"},
    "lta": {"lta.gov.sg", "onemotoring.lta.gov.sg"},
    "hdb": {"hdb.gov.sg"},
    "mas": {"mas.gov.sg"},
    "gov.sg": {"gov.sg"},
    # Singapore utilities, telcos, logistics, and marketplaces.
    "singpost": {"singpost.com", "singpost.com.sg"},
    "singtel": {"singtel.com"},
    "starhub": {"starhub.com"},
    "sp group": {"spgroup.com.sg"},
    "shopee": {"shopee.sg", "shopee.com"},
    "lazada": {"lazada.sg", "lazada.com"},
    "carousell": {"carousell.com", "carousell.sg"},
    "ez-link": {"ezlink.com.sg"},
}


def _domain_of(address: str) -> str:
    _, addr = parseaddr(address or "")
    if "@" not in addr:
        return ""
    return addr.rsplit("@", 1)[1].strip().lower().rstrip(">")


def _registrable(domain: str) -> str:
    """Crude eTLD+1. Good enough to compare 'mail.dbs.com.sg' with 'dbs.com.sg'."""
    if not domain:
        return ""
    parts = domain.split(".")
    if len(parts) <= 2:
        return domain
    # Handle the common two-part suffixes this project actually meets.
    two_part = {"co.in", "co.uk", "org.in", "gov.in", "ac.in", "net.in", "com.au", "co.jp"}
    if ".".join(parts[-2:]) in two_part and len(parts) >= 3:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


MARKDOWN_LINK = re.compile(r"\[([^\]]+)\]\((mailto:)?([^)\s]+)\)")


def normalise(raw: str) -> str:
    """Clean up the ways a real paste arrives before the parser sees it.

    Chat apps and rich-text editors rewrite links as markdown, indent quoted
    blocks, and leave blank lines at the top. All three break header parsing,
    and none of them are the user's fault.
    """
    text = (raw or "").replace("\ufeff", "").replace("\r\n", "\n").replace("\r", "\n")

    # [label](mailto:a@b.com) -> label, so the From line stays parseable.
    # [label](https://x) -> a real anchor, so the link-mismatch check still fires.
    def unmark(match: re.Match) -> str:
        label, is_mailto, target = match.group(1), match.group(2), match.group(3)
        if is_mailto or "@" in target and "://" not in target:
            return label
        return f'<a href="{target}">{label}</a>'

    text = MARKDOWN_LINK.sub(unmark, text)

    lines = text.split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)

    # Un-indent header lines that were pasted from a quoted block.
    for index, line in enumerate(lines):
        if re.match(r"^\s+[A-Za-z-]+:\s", line) and not re.match(r"^\s+\S", lines[index - 1] if index else ""):
            lines[index] = line.lstrip()
    return "\n".join(lines)


def parse_email(raw: str) -> tuple[EmailMessage, bool]:
    """Parse a paste. Returns the message and whether real headers were found."""
    text = normalise(raw)
    if not text.strip():
        raise ExtractionError("Paste the email, including its headers, or upload a .eml file.")
    try:
        message = email.message_from_string(text, policy=policy.default)
    except Exception as exc:
        raise ExtractionError("That email could not be parsed.") from exc

    has_headers = bool(message.get("From") or message.get("Subject") or message.get("Received"))
    if not has_headers:
        # No headers at all, so treat the whole paste as the body rather than
        # refusing. The wording can still be judged; the caller adds a note.
        message = email.message_from_string(f"Subject: \n\n{text}", policy=policy.default)
    return message, has_headers


def _body_parts(message: EmailMessage) -> tuple[str, str]:
    """Return (plain_text, html) for the message body."""
    plain, html = "", ""
    if message.is_multipart():
        for part in message.walk():
            if part.get_content_disposition() == "attachment":
                continue
            ctype = part.get_content_type()
            try:
                payload = part.get_content()
            except Exception:
                continue
            if ctype == "text/plain" and not plain:
                plain = str(payload)
            elif ctype == "text/html" and not html:
                html = str(payload)
    else:
        try:
            content = str(message.get_content())
        except Exception:
            content = ""
        if message.get_content_type() == "text/html":
            html = content
        else:
            plain = content
    return plain, html


def _strip_html(html: str) -> str:
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = (text.replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"'))
    return re.sub(r"\s+", " ", text).strip()


def _anchor_mismatches(html: str) -> list[tuple[str, str]]:
    """Find anchors whose visible text names one domain but whose href is another."""
    mismatches = []
    for match in re.finditer(r'(?is)<a\b[^>]*href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>', html):
        href, label = match.group(1), _strip_html(match.group(2))
        href_host = _registrable(_host_of(href))
        label_host = ""
        label_match = re.search(r"\b([a-z0-9-]+(?:\.[a-z0-9-]+)+)\b", label, re.IGNORECASE)
        if label_match:
            label_host = _registrable(label_match.group(1).lower())
        if href_host and label_host and href_host != label_host:
            mismatches.append((label_host, href_host))
    return mismatches


def _auth_results(message: EmailMessage) -> list[ExtractedSignal]:
    """Read what the receiving mail server already decided about authenticity."""
    signals: list[ExtractedSignal] = []
    blob = " ".join(
        str(value) for key, value in message.items()
        if key.lower() in {"authentication-results", "received-spf", "arc-authentication-results"}
    ).lower()
    if not blob:
        return signals

    checks = [
        ("spf", r"spf=(fail|softfail)", "SPF check failed",
         "The sending server was not authorised to send mail for that domain."),
        ("dkim", r"dkim=fail", "DKIM signature failed",
         "The message signature does not validate, so the content or sender may have been altered."),
        ("dmarc", r"dmarc=fail", "DMARC policy failed",
         "The domain owner's own anti-spoofing policy rejects this message."),
    ]
    for _name, pattern, label, detail in checks:
        if re.search(pattern, blob):
            signals.append(ExtractedSignal(label, detail, 0.30))

    if not signals and re.search(r"spf=pass", blob) and re.search(r"dkim=pass", blob):
        signals.append(ExtractedSignal(
            "Sender authentication passed",
            "SPF and DKIM both validate, so the message really came from the domain it claims.",
            -0.12,
            "safe",
        ))
    return signals


def analyze_email_headers(message: EmailMessage) -> tuple[list[ExtractedSignal], dict]:
    signals: list[ExtractedSignal] = []

    from_header = str(message.get("From", ""))
    display_name, from_addr = parseaddr(from_header)
    from_domain = _domain_of(from_header)
    from_root = _registrable(from_domain)

    reply_to = str(message.get("Reply-To", ""))
    reply_root = _registrable(_domain_of(reply_to)) if reply_to else ""
    return_path = str(message.get("Return-Path", ""))
    return_root = _registrable(_domain_of(return_path)) if return_path else ""

    # 1. Reply-To redirects somewhere else entirely.
    if reply_root and from_root and reply_root != from_root:
        signals.append(ExtractedSignal(
            "Reply-To points elsewhere",
            f"Replies would go to {reply_root}, not {from_root}. This is how a reply gets hijacked.",
            0.32,
        ))

    # 2. Envelope sender disagrees with the visible sender.
    if return_root and from_root and return_root != from_root:
        signals.append(ExtractedSignal(
            "Envelope sender mismatch",
            f"The message was actually posted by {return_root} while displaying {from_root}.",
            0.22,
        ))

    # 3. Display name impersonates a brand from an address that cannot own it.
    lowered_name = display_name.lower()
    for brand, official in BRAND_DOMAINS.items():
        if brand in lowered_name and from_root:
            if from_root in official:
                continue
            if from_domain in FREEMAIL_DOMAINS:
                signals.append(ExtractedSignal(
                    "Brand name on a free mailbox",
                    f"The sender presents as '{display_name.strip()}' but writes from {from_domain}. "
                    f"{brand.title()} would use its own domain.",
                    0.34,
                ))
            else:
                signals.append(ExtractedSignal(
                    "Sender domain does not match the brand",
                    f"Claims to be {brand.title()} but sends from {from_root}, which {brand.title()} does not own.",
                    0.30,
                ))
            break

    # 4. Display name contains an email address different from the real one.
    embedded = re.search(r"[\w.+-]+@[\w.-]+\.\w+", display_name)
    if embedded and _registrable(embedded.group(0).rsplit("@", 1)[1].lower()) != from_root:
        signals.append(ExtractedSignal(
            "Fake address in the sender name",
            f"The display name shows {embedded.group(0)} while the real address is {from_addr}.",
            0.33,
        ))

    # 5. Lookalike domain: brand token buried in a longer domain.
    if from_root:
        stem = from_root.split(".")[0]
        for brand, official in BRAND_DOMAINS.items():
            token = brand.replace(" ", "")
            if token in stem and from_root not in official and stem != token:
                signals.append(ExtractedSignal(
                    "Lookalike sender domain",
                    f"'{from_root}' borrows the {brand.title()} name without being an official domain.",
                    0.28,
                ))
                break

    # 5b. Domain assembled from security words rather than a real brand.
    if from_root and from_root not in {d for domains in BRAND_DOMAINS.values() for d in domains}:
        stem = from_root.rsplit(".", 1)[0].replace(".", "-")
        theatre = {
            "secure", "security", "secuirty", "verify", "verification", "verified",
            "login", "signin", "account", "accounts", "update", "alert", "alerts",
            "support", "recovery", "confirm", "auth", "notice", "service", "desk",
        }
        parts = {part for part in re.split(r"[-_]", stem) if part}
        hits = parts & theatre
        if len(hits) >= 2 or (hits and len(parts) >= 3):
            signals.append(ExtractedSignal(
                "Sender domain is built from security words",
                f"'{from_root}' is stitched together from words like {', '.join(sorted(hits)[:2])}. "
                "Real organisations send from their own name, not a description of what they want you to do.",
                0.26,
            ))

    # 6. Authentication results recorded by the receiving server.
    signals.extend(_auth_results(message))

    # 7. Undisclosed or mismatched recipient.
    to_header = str(message.get("To", ""))
    if not to_header or "undisclosed" in to_header.lower():
        signals.append(ExtractedSignal(
            "Recipient hidden",
            "The message has no visible recipient, typical of a list blast rather than a personal email.",
            0.12,
        ))
    elif len(getaddresses([to_header])) > 15:
        signals.append(ExtractedSignal(
            "Mass recipient list",
            "This was sent to a large batch of addresses at once.",
            0.14,
        ))

    meta = {
        "from": from_addr,
        "from_display": display_name.strip(),
        "from_domain": from_domain,
        "reply_to": parseaddr(reply_to)[1] if reply_to else "",
        "to": to_header[:200],
        "subject": str(message.get("Subject", "")),
        "date": str(message.get("Date", "")),
        "hops": len(message.get_all("Received") or []),
    }
    return signals, meta


def analyze_email_body(message: EmailMessage) -> tuple[str, list[ExtractedSignal], dict]:
    plain, html = _body_parts(message)
    signals: list[ExtractedSignal] = []

    body_text = plain or _strip_html(html)

    if html:
        mismatches = _anchor_mismatches(html)
        if mismatches:
            label_host, href_host = mismatches[0]
            signals.append(ExtractedSignal(
                "Link text hides its real target",
                f"A link reads '{label_host}' but actually goes to {href_host}"
                + (f", and {len(mismatches) - 1} more do the same." if len(mismatches) > 1 else "."),
                0.36,
            ))

    urls = re.findall(r"https?://[^\s<>\"')]+", (plain or "") + " " + html)
    domains = {_host_of(url) for url in urls}
    domains.discard("")

    shortened = sorted(d for d in domains if _registrable(d) in SHORTENERS)
    if shortened:
        signals.append(ExtractedSignal(
            "Shortened link",
            f"Uses {shortened[0]} to hide where the link really leads.",
            0.20,
        ))
    raw_ips = sorted(d for d in domains if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", d))
    if raw_ips:
        signals.append(ExtractedSignal(
            "Link points to a raw IP address",
            f"A link goes straight to {raw_ips[0]} instead of a named domain.",
            0.28,
        ))
    punycode = sorted(d for d in domains if d.startswith("xn--") or ".xn--" in d)
    if punycode:
        signals.append(ExtractedSignal(
            "Lookalike domain characters",
            "A link uses punycode, which disguises foreign characters as ordinary letters.",
            0.30,
        ))

    attachments = []
    for part in message.walk():
        if part.get_content_disposition() == "attachment":
            name = part.get_filename() or "unnamed"
            attachments.append(name)
            lowered = name.lower()
            suffix = "." + lowered.rsplit(".", 1)[-1] if "." in lowered else ""
            if suffix in DANGEROUS_ATTACHMENT_EXTENSIONS:
                signals.append(ExtractedSignal(
                    "Executable attachment",
                    f"'{name}' is a program, not a document. Opening it would run code on your machine.",
                    0.40,
                ))
            elif re.search(r"\.(pdf|docx?|jpe?g|png|xlsx?)\.[a-z0-9]{2,4}$", lowered):
                signals.append(ExtractedSignal(
                    "Double file extension",
                    f"'{name}' is disguised to look like a document but is something else.",
                    0.38,
                ))

    meta = {
        "linked_domains": sorted(domains)[:10],
        "attachments": attachments[:10],
        "has_html": bool(html),
    }
    return body_text, signals, meta


def extract_email(raw: str) -> ExtractionResult:
    message, has_headers = parse_email(raw)
    header_signals, header_meta = analyze_email_headers(message)
    body_text, body_signals, body_meta = analyze_email_body(message)

    subject = header_meta.get("subject", "")
    combined = f"{subject}\n\n{body_text}".strip()

    if not combined:
        # Headers parsed but nothing followed them, usually because the blank
        # line between headers and body was lost in copying. Analyse the paste
        # as it stands rather than refusing it.
        combined = normalise(raw).strip()
    if not combined:
        raise ExtractionError("That email was empty.")

    signals = header_signals + body_signals
    if not has_headers:
        signals.append(ExtractedSignal(
            "No headers supplied",
            "Only the wording could be checked. Paste the full source (Gmail: Show original) to "
            "have the sender, Reply-To and authentication results checked too.",
            0.0,
            "safe",
        ))

    meta = {**header_meta, **body_meta, "headers_present": has_headers}
    return ExtractionResult(
        text=combined[:20000],
        source="email",
        meta=meta,
        signals=signals,
    )
