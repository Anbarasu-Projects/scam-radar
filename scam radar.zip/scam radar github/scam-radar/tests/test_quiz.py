"""Tests for the scam-awareness quiz."""
import json
import os
import sys
from pathlib import Path

import pytest

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

os.environ.setdefault("SCAMSHIELD_DB", str(Path(__file__).with_name("test_quiz.db")))

import quiz  # noqa: E402
from app import app  # noqa: E402


@pytest.fixture()
def client():
    return app.test_client()


def test_round_returns_five_distinct_questions(client):
    body = client.get("/api/quiz").get_json()
    assert body["total"] == 5
    assert len(body["questions"]) == 5
    assert len({q["id"] for q in body["questions"]}) == 5


def test_answers_are_never_sent_to_the_browser(client):
    raw = json.dumps(client.get("/api/quiz").get_json())
    assert "answer" not in raw
    assert "explanation" not in raw


def test_every_question_has_at_least_three_options(client):
    for question in client.get("/api/quiz?count=15").get_json()["questions"]:
        assert len(question["options"]) >= 3
        assert question["prompt"].strip()


def test_bank_answers_are_all_in_range():
    for question in quiz.QUESTION_BANK:
        assert 0 <= question["answer"] < len(question["options"])
        assert question["explanation"].strip()


def test_bank_ids_are_unique():
    ids = [question["id"] for question in quiz.QUESTION_BANK]
    assert len(ids) == len(set(ids))


def test_correct_answer_is_marked_right(client):
    question = quiz.QUESTION_BANK[0]
    body = client.post("/api/quiz/answer", json={"id": question["id"], "choice": question["answer"]}).get_json()
    assert body["correct"] is True
    assert body["explanation"]


def test_wrong_answer_returns_the_right_one(client):
    question = quiz.QUESTION_BANK[0]
    wrong = (question["answer"] + 1) % len(question["options"])
    body = client.post("/api/quiz/answer", json={"id": question["id"], "choice": wrong}).get_json()
    assert body["correct"] is False
    assert body["answer"] == question["answer"]


def test_unknown_question_is_rejected(client):
    assert client.post("/api/quiz/answer", json={"id": "not-a-question", "choice": 0}).status_code == 404


def test_missing_choice_is_rejected(client):
    assert client.post("/api/quiz/answer", json={"id": quiz.QUESTION_BANK[0]["id"]}).status_code == 400


def test_result_feedback_scales_with_score(client):
    top = client.post("/api/quiz/result", json={"score": 5, "total": 5}).get_json()
    bottom = client.post("/api/quiz/result", json={"score": 0, "total": 5}).get_json()
    assert top["headline"] != bottom["headline"]
    assert top["score"] == 5


def test_impossible_score_is_rejected(client):
    assert client.post("/api/quiz/result", json={"score": 9, "total": 5}).status_code == 400
    assert client.post("/api/quiz/result", json={"score": -1, "total": 5}).status_code == 400
