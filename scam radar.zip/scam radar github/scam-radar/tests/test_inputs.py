"""Tests for the email, document, and voice input routes."""
import io
import os
import sys
from pathlib import Path

import pytest

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

os.environ["SCAMSHIELD_DB"] = str(Path(__file__).with_name("test_inputs.db"))

from app import app  # noqa: E402

PHISHING_EMAIL = """From: "DBS Bank Security" <alerts@dbs-secure-verify.co>
Reply-To: recovery@mail-secure-desk.com
To: undisclosed-recipients:;
Subject: Urgent: your account will be blocked today
Authentication-Results: mx.google.com; spf=fail; dkim=fail; dmarc=fail
Content-Type: text/html

<html><body><p>Dear customer, your account verification expires today. Confirm now or your account
will be suspended.</p><a href="http://bit.ly/dbs-now">www.dbs.com.sg</a></body></html>
"""

LEGIT_EMAIL = """From: "Amazon.sg" <shipment-tracking@amazon.sg>
Reply-To: shipment-tracking@amazon.in
To: student@example.com
Subject: Your order has shipped
Authentication-Results: mx.google.com; spf=pass; dkim=pass header.d=amazon.sg; dmarc=pass
Content-Type: text/plain

Hi, your order has been shipped and will arrive by Friday. Track it in the official app.
"""


@pytest.fixture()
def client():
    return app.test_client()


def labels(body):
    return {signal["label"] for signal in body["signals"]}


def test_capabilities_lists_every_input(client):
    body = client.get("/api/capabilities").get_json()
    assert body["text"] is True
    assert body["email"] is True
    assert "pdf" in body["document"]
    assert "server_transcription" in body["voice"]


def test_phishing_email_is_flagged_with_header_evidence(client):
    response = client.post("/api/analyze-email", json={"raw": PHISHING_EMAIL})
    body = response.get_json()
    assert response.status_code == 201
    assert body["verdict"] == "SCAM"
    assert body["source"] == "email"
    found = labels(body)
    assert "Reply-To points elsewhere" in found
    assert "SPF check failed" in found
    assert "Link text hides its real target" in found
    assert body["meta"]["from_domain"] == "dbs-secure-verify.co"


def test_authenticated_email_is_not_flagged(client):
    body = client.post("/api/analyze-email", json={"raw": LEGIT_EMAIL}).get_json()
    assert body["verdict"] == "LEGIT"
    assert "Sender authentication passed" in labels(body)


def test_headerless_text_is_analyzed_rather_than_refused(client):
    """Refusing a paste is worse than analysing what is there and saying so."""
    response = client.post("/api/analyze-email", json={"raw": "just some words"})
    body = response.get_json()
    assert response.status_code == 201
    assert body["meta"]["headers_present"] is False


def test_text_file_upload_is_analyzed(client):
    data = b"URGENT! Your DBS account is locked. Click http://bit.ly/fake and share your OTP now."
    response = client.post(
        "/api/analyze-file",
        data={"file": (io.BytesIO(data), "notice.txt")},
        content_type="multipart/form-data",
    )
    body = response.get_json()
    assert response.status_code == 201
    assert body["verdict"] == "SCAM"
    assert body["source"] == "document"


def test_executable_upload_is_refused(client):
    response = client.post(
        "/api/analyze-file",
        data={"file": (io.BytesIO(b"MZ\x90\x00"), "invoice.pdf.exe")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 400
    assert "executable" in response.get_json()["error"].lower()


def test_empty_upload_is_rejected(client):
    response = client.post(
        "/api/analyze-file",
        data={"file": (io.BytesIO(b""), "empty.txt")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 400


def test_docx_upload_is_analyzed(client):
    docx = pytest.importorskip("docx")
    document = docx.Document()
    document.add_paragraph("Your IRAS tax refund of S$1,850 is pending.")
    document.add_paragraph("Share your card number and CVV at the link to receive it today.")
    buffer = io.BytesIO()
    document.save(buffer)
    response = client.post(
        "/api/analyze-file",
        data={"file": (io.BytesIO(buffer.getvalue()), "refund.docx")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 201
    assert response.get_json()["verdict"] == "SCAM"


def test_voice_transcript_detects_vishing(client):
    transcript = (
        "Sir do not hang up. I am calling from the cyber crime department. A case has been "
        "registered against your NRIC. Tell me the OTP you just received and install AnyDesk."
    )
    response = client.post("/api/analyze-audio", json={"transcript": transcript})
    body = response.get_json()
    assert response.status_code == 201
    assert body["verdict"] == "SCAM"
    assert body["source"] == "voice"
    assert "Asked to read out a code" in labels(body)
    assert "Remote access request" in labels(body)


def test_ordinary_call_transcript_is_not_flagged(client):
    transcript = "Hi, this is Rahul from the study group. Are we still meeting at the library at six?"
    body = client.post("/api/analyze-audio", json={"transcript": transcript}).get_json()
    assert body["verdict"] == "LEGIT"


def test_short_transcript_is_rejected(client):
    response = client.post("/api/analyze-audio", json={"transcript": "hi"})
    assert response.status_code == 400


def test_history_records_the_input_source(client):
    client.post("/api/analyze-email", json={"raw": PHISHING_EMAIL})
    body = client.get("/api/history").get_json()
    assert body["summary"]["total"] >= 1
    assert any(item["source"] == "email" for item in body["items"])


MESSY_PASTE = """From: Security Alert [support@secuirty-update-login.com](mailto:support@secuirty-update-login.com)
Subject: URGENT: Your account has been temporarily locked due to unusual login activity
Dear Customer,
We noticed a login attempt from an unrecognized device. Confirm your identity within 24 hours
to avoid permanent suspension of your account.
Click here to verify your account
"""


def test_paste_without_a_blank_line_still_parses(client):
    """Copying an email by hand usually loses the header/body separator."""
    response = client.post("/api/analyze-email", json={"raw": MESSY_PASTE})
    body = response.get_json()
    assert response.status_code == 201
    assert body["verdict"] == "SCAM"


def test_markdown_links_from_chat_apps_are_unwrapped(client):
    body = client.post("/api/analyze-email", json={"raw": MESSY_PASTE}).get_json()
    assert body["meta"]["from_domain"] == "secuirty-update-login.com"


def test_indented_and_blank_padded_paste_still_parses(client):
    padded = "\n\n" + "\n".join("   " + line for line in MESSY_PASTE.split("\n"))
    assert client.post("/api/analyze-email", json={"raw": padded}).status_code == 201


def test_security_theatre_domain_is_flagged(client):
    body = client.post("/api/analyze-email", json={"raw": MESSY_PASTE}).get_json()
    assert "Sender domain is built from security words" in labels(body)


def test_ordinary_support_address_is_not_flagged(client):
    raw = "From: support@notion.so\nSubject: Welcome\n\nThanks for signing up, your workspace is ready."
    body = client.post("/api/analyze-email", json={"raw": raw}).get_json()
    assert "Sender domain is built from security words" not in labels(body)


def test_body_without_headers_is_analyzed_with_a_note(client):
    raw = "Dear customer, your account is locked. Click http://bit.ly/x and share your OTP now."
    response = client.post("/api/analyze-email", json={"raw": raw})
    body = response.get_json()
    assert response.status_code == 201
    assert body["verdict"] == "SCAM"
    assert "No headers supplied" in labels(body)
    assert body["meta"]["headers_present"] is False


def test_blank_email_is_still_rejected(client):
    assert client.post("/api/analyze-email", json={"raw": "   "}).status_code == 400
