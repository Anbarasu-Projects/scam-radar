import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Brain,
  Check,
  ChevronDown,
  CircleAlert,
  CircleCheck,
  Copy,
  FileText,
  Fingerprint,
  History,
  Link2,
  LoaderCircle,
  LockKeyhole,
  Mail,
  Menu,
  MessageSquareText,
  Mic,
  Radio,
  RotateCcw,
  ScanLine,
  ShieldCheck,
  Square,
  Trash2,
  Upload,
  X,
} from "lucide-react";

// API location priority:
// 1) Vite environment variable for a conventional deployment.
// 2) Hugging Face Static Space variable for the free hosted demo.
// 3) Relative /api path, proxied by Vite to Flask during local development.
const HF_API_URL = window.huggingface?.variables?.API_BASE_URL;
const API_BASE = (import.meta.env.VITE_API_URL || HF_API_URL || "").replace(/\/$/, "");

const reducedMotion = () =>
  typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/* ----------------------------------------------------------------- router */

const ROUTES = [
  { path: "/scan", label: "Scan" },
  { path: "/method", label: "Method" },
  { path: "/quiz", label: "Quiz" },
  { path: "/history", label: "History" },
  { path: "/faq", label: "Questions" },
];

/** Change page without a reload. Flask serves index.html for any unknown
 *  path, so these are real URLs you can bookmark, refresh and share. */
function navigate(to) {
  if (window.location.pathname === to) return;
  window.history.pushState({}, "", to);
  window.dispatchEvent(new PopStateEvent("popstate"));
}

function useRoute() {
  const [path, setPath] = useState(window.location.pathname);
  useEffect(() => {
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  return path === "/" ? "/" : path.replace(/\/$/, "");
}

function Link({ to, className, onClick, children }) {
  return (
    <a
      href={to}
      className={className}
      onClick={(event) => {
        // Let the browser handle new-tab and middle clicks as usual.
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return;
        event.preventDefault();
        navigate(to);
        onClick?.();
      }}
    >
      {children}
    </a>
  );
}

/* ------------------------------------------------------------------ hooks */

function useCountUp(target, duration = 1000, start = true) {
  const [value, setValue] = useState(start && !reducedMotion() ? 0 : target);

  useEffect(() => {
    if (!start) return undefined;
    if (reducedMotion()) {
      setValue(target);
      return undefined;
    }
    let frame;
    const began = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - began) / duration, 1);
      setValue(Math.round(target * (1 - (1 - progress) ** 3)));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, duration, start]);

  return value;
}

function useInView(threshold = 0.3) {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node || seen) return undefined;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setSeen(true);
        observer.disconnect();
      }
    }, { threshold });
    observer.observe(node);
    return () => observer.disconnect();
  }, [seen, threshold]);

  return [ref, seen];
}

/* ------------------------------------------------------------------- data */

const INPUTS = [
  { id: "text", label: "Message", hint: "SMS or chat", icon: MessageSquareText },
  { id: "email", label: "Email", hint: "Headers and body", icon: Mail },
  { id: "document", label: "Document", hint: "PDF, Word, screenshot", icon: FileText },
  { id: "voice", label: "Voice", hint: "Recorded call", icon: Mic },
];

const EXAMPLES = [
  {
    label: "Bank alert",
    tone: "bad",
    text: "URGENT! Your DBS account will be suspended today. Verify now at http://bit.ly/dbs-verify and enter your OTP.",
  },
  {
    label: "Prize draw",
    tone: "bad",
    text: "Congratulations! You won S$250,000 in the Singapore Sweep. Pay the S$299 processing fee today to claim your prize.",
  },
  {
    label: "Parcel hold",
    tone: "bad",
    text: "Your SingPost parcel is held at customs. Settle the unpaid duty at this link within 12 hours or it will be returned.",
  },
  {
    label: "Real delivery",
    tone: "good",
    text: "Your order has shipped and will arrive by Friday. Track it in the official app.",
  },
];

const EMAIL_SAMPLE = [
  'From: "DBS Bank Security" <alerts@dbs-secure-verify.co>',
  "Reply-To: recovery@mail-secure-desk.com",
  "To: undisclosed-recipients:;",
  "Subject: Urgent: your account will be locked today",
  "Authentication-Results: mx.google.com; spf=fail; dkim=fail; dmarc=fail",
  "Return-Path: <bounce@sendgrid-relay.net>",
  "Content-Type: text/html",
  "",
  "<html><body><p>Dear customer, your account verification expires today.",
  "Confirm now or your account will be permanently suspended.</p>",
  '<a href="http://bit.ly/dbs-now">www.dbs.com.sg</a></body></html>',
].join("\n");

const STEPS = [
  {
    title: "It reads the words",
    body: "Two TF-IDF views, one over words and one over character patterns, feed a logistic regression trained on scam and ordinary messages. The character view catches the deliberate misspellings that slip past a plain word model.",
  },
  {
    title: "It reads the structure",
    body: "Email headers, PDF internals and call transcripts carry evidence the wording never shows: a Reply-To that redirects, a failed DKIM signature, script buried in an invoice, a caller telling you not to hang up.",
  },
  {
    title: "It shows its working",
    body: "Both layers blend into one probability, capped so no single finding can steamroll the rest. Every piece of evidence is named, so you are free to disagree with it.",
  },
];

const FAQS = [
  {
    q: "How does it decide?",
    a: "A TF-IDF model reads word and character patterns while a rule layer checks for urgency, disguised links, credential requests, threats and payment pressure. Structural findings from emails and files fold in afterwards, and the blend is capped so one signal cannot dominate the verdict.",
  },
  {
    q: "Which scams is it tuned for?",
    a: "The ones Singapore actually sees: bank and Singpass phishing, PayNow transfer requests, SingPost and customs parcel holds, job and task scams, prize draws, government impersonation, and remote access requests.",
  },
  {
    q: "Where does my data go?",
    a: "Nowhere. Everything runs on the Flask server you started, and scans are kept only in a local SQLite file so you can look back at them. No message reaches an external AI service, and you can erase the whole history in one click.",
  },
  {
    q: "Can it be wrong?",
    a: "Yes, and it will be. Treat it as a second opinion, not a verdict. When money or credentials are involved, verify through a number or app you already had, never one supplied by the message itself.",
  },
];

/* ---------------------------------------------------------------- chrome */

function Wordmark({ onClick }) {
  return (
    <Link to="/" className="wordmark" onClick={onClick}>
      <span className="wordmark-glyph"><ShieldCheck size={16} strokeWidth={2.4} /></span>
      Scam Radar
    </Link>
  );
}

function Header({ route }) {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="masthead">
      <div className="shell masthead-inner">
        <Wordmark onClick={close} />
        <nav className={open ? "nav open" : "nav"}>
          {ROUTES.map(({ path, label }) => (
            <Link key={path} to={path} className={route === path ? "active" : ""} onClick={close}>
              {label}
            </Link>
          ))}
        </nav>
        <Link to="/scan" className="btn btn-solid masthead-cta" onClick={close}>
          Check a message <ArrowRight size={15} />
        </Link>
        <button className="nav-toggle" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X size={19} /> : <Menu size={19} />}
        </button>
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ hero */

function ThreadDemo() {
  return (
    <div className="thread" aria-hidden="true">
      <div className="thread-top">
        <span className="thread-avatar">65</span>
        <div className="thread-who">
          <strong>+65 8•• ••• 41</strong>
          <small>Not in your contacts</small>
        </div>
        <Radio size={14} />
      </div>

      <div className="bubble b1">Hi, is this Marcus?</div>
      <div className="bubble b2">
        I&apos;m from the DBS fraud team. Your account shows an unauthorised transfer of S$4,820.
      </div>
      <div className="bubble b3">
        To reverse it, verify at <span className="marked">bit.ly/dbs-verify</span> and read me the{" "}
        <span className="marked">OTP</span>. Don&apos;t hang up.
      </div>

      <div className="thread-verdict">
        <span className="stamp">Scam · 94% sure</span>
        <ul>
          <li>Link hides its real destination</li>
          <li>Asks you to read out a code</li>
          <li>Pressure to stay on the line</li>
        </ul>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section className="hero" id="top">
      <div className="shell hero-inner">
        <div className="hero-copy">
          <p className="hero-eyebrow"><span className="live-dot" /> Runs on your machine, nothing leaves it</p>
          <h1>
            It is built to
            <br />
            sound like someone
            <br />
            <em>you already trust.</em>
          </h1>
          <p className="hero-sub">
            Paste a text, forward an email, drop in a screenshot, or record the call.
            Scam Radar returns a verdict and names the evidence behind it, so you can
            judge the reasoning instead of trusting a number.
          </p>
          <div className="hero-actions">
            <Link to="/scan" className="btn btn-solid btn-lg">
              Open the inspector <ArrowRight size={17} />
            </Link>
            <Link to="/method" className="btn btn-outline btn-lg">How it decides</Link>
          </div>
        </div>
        <ThreadDemo />
      </div>
    </section>
  );
}

/* --------------------------------------------------------------- verdict */

function MetaRows({ meta, source }) {
  if (!meta) return null;
  const rows = [];
  if (source === "email") {
    if (meta.from) rows.push(["Sender", meta.from]);
    if (meta.reply_to && meta.reply_to !== meta.from) rows.push(["Replies go to", meta.reply_to]);
    if (meta.subject) rows.push(["Subject", meta.subject]);
    if (meta.linked_domains?.length) rows.push(["Links to", meta.linked_domains.join(", ")]);
    if (meta.attachments?.length) rows.push(["Attached", meta.attachments.join(", ")]);
  } else if (source === "document") {
    if (meta.filename) rows.push(["File", meta.filename]);
    if (meta.pages) rows.push(["Pages", String(meta.pages)]);
    if (meta.ocr_engine) rows.push(["Read with", meta.ocr_engine]);
    if (meta.linked_domains?.length) rows.push(["Links to", meta.linked_domains.join(", ")]);
  } else if (source === "voice") {
    if (meta.engine) rows.push(["Transcribed by", meta.engine]);
    if (meta.duration_seconds) rows.push(["Length", `${meta.duration_seconds}s`]);
    if (meta.transcript) rows.push(["Heard", meta.transcript]);
  }
  if (!rows.length) return null;
  return (
    <dl className="meta-rows">
      {rows.map(([label, value]) => (
        <div key={label}>
          <dt>{label}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function Gauge({ value, scam }) {
  const shown = useCountUp(Math.round(value), 1100);
  return (
    <div className={`gauge ${scam ? "bad" : "good"}`} style={{ "--pct": `${value * 3.6}deg` }}>
      <div className="gauge-face">
        <strong>{shown}</strong>
        <small>% sure</small>
      </div>
    </div>
  );
}

function Verdict({ result, onReset }) {
  const scam = result.verdict === "SCAM";
  return (
    <div className={`verdict ${scam ? "is-bad" : "is-good"}`}>
      <div className="verdict-head">
        <div>
          <span className="verdict-tag">
            {scam ? <CircleAlert size={14} /> : <CircleCheck size={14} />}
            {scam ? "Treat this as a scam" : "Nothing alarming found"}
            {result.source && result.source !== "text" && <b>{result.source}</b>}
          </span>
          <h3>{scam ? "This one is trying to move you." : "This reads like an ordinary message."}</h3>
        </div>
        <Gauge value={result.confidence} scam={scam} />
      </div>

      <div className="verdict-facts">
        <div><span>Risk</span><strong>{result.risk_level}</strong></div>
        <div><span>Scam probability</span><strong>{result.scam_probability}%</strong></div>
        <div><span>Wording alone</span><strong>{result.model_probability}%</strong></div>
      </div>

      <MetaRows meta={result.meta} source={result.source} />

      <div className="evidence">
        <p className="evidence-title">Evidence<b>{result.signals.length}</b></p>
        <ol>
          {result.signals.map((signal, index) => (
            <li key={`${signal.label}-${index}`} className={signal.kind} style={{ "--i": index }}>
              <span className="evidence-dot" />
              <div>
                <strong>{signal.label}</strong>
                <p>{signal.detail}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>

      <p className="advice"><ShieldCheck size={17} /> {result.advice}</p>
      <button className="btn btn-outline" onClick={onReset}>
        <RotateCcw size={14} /> Check something else
      </button>
    </div>
  );
}

function Waiting({ busy }) {
  return (
    <div className="waiting">
      <div className={`radar ${busy ? "busy" : ""}`}>
        <span className="radar-ring" />
        <span className="radar-ring" />
        <span className="radar-ring" />
        <span className="radar-cross" />
        <span className="radar-sweep" />
        <span className="radar-blip" />
        <span className="radar-blip two" />
        <ScanLine size={22} />
      </div>
      <h3>{busy ? "Reading it now" : "Nothing loaded yet"}</h3>
      <p>
        {busy
          ? "Checking the wording, the structure and every link."
          : "Choose an input on the left. The verdict and the evidence behind it land here."}
      </p>
    </div>
  );
}

/* ---------------------------------------------------------- email view */

/** Split raw email source into headers and body, the way a mail client does. */
function parseRawEmail(raw) {
  // Match the server's tolerance: chat apps rewrite links as markdown, and
  // quoted blocks arrive indented with blank lines on top.
  let text = (raw || "").replace(/\ufeff/g, "").replace(/\r\n?/g, "\n");
  text = text.replace(/\[([^\]]+)\]\((mailto:)?([^)\s]+)\)/g, (all, label, mailto, target) =>
    mailto || (target.includes("@") && !target.includes("://")) ? label : `<a href="${target}">${label}</a>`
  );
  text = text.replace(/^\n+/, "").replace(/^[ \t]+(?=[A-Za-z-]+:\s)/gm, "");
  let split = text.indexOf("\n\n");
  if (split === -1) {
    // No blank line, so fall back to the first line that is not a header.
    const lines = text.split("\n");
    const index = lines.findIndex((line, i) => i > 0 && !/^[A-Za-z-]+:\s/.test(line) && line.trim());
    split = index === -1 ? text.length : lines.slice(0, index).join("\n").length;
  }
  const headers = {};
  text.slice(0, split).split("\n").forEach((line) => {
    const colon = line.indexOf(":");
    if (colon > 0) headers[line.slice(0, colon).trim().toLowerCase()] = line.slice(colon + 1).trim();
  });

  const body = text.slice(split).trim();
  const links = [];
  const anchor = /<a\b[^>]*href=["']?([^"'>\s]+)["']?[^>]*>(.*?)<\/a>/gis;
  let match = anchor.exec(body);
  while (match) {
    links.push({ href: match[1], label: match[2].replace(/<[^>]+>/g, "").trim() });
    match = anchor.exec(body);
  }
  const bare = body.replace(/<a\b[^>]*>.*?<\/a>/gis, " ").match(/https?:\/\/[^\s<>"')]+/g) || [];
  bare.forEach((href) => links.push({ href, label: "" }));

  const plain = body
    .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, " ")
    .replace(/<\/p>|<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return { headers, plain, links };
}

function hostOf(url) {
  const match = /^https?:\/\/([^/\s:]+)/i.exec(url || "");
  return match ? match[1].toLowerCase() : "";
}

function EmailPreview({ raw }) {
  if (!raw.trim()) {
    return (
      <div className="preview empty">
        <Mail size={22} />
        <p>Nothing to show yet. Paste an email in the raw view, or load the sample.</p>
      </div>
    );
  }

  const { headers, plain, links } = parseRawEmail(raw);
  const from = headers.from || "Unknown sender";
  const name = /"?([^"<]+)"?\s*</.exec(from)?.[1]?.trim() || from;
  const address = /<([^>]+)>/.exec(from)?.[1] || (from.includes("@") ? from : "");
  const replyTo = headers["reply-to"] || "";
  const redirected = replyTo && hostOf(`http://${replyTo.split("@").pop()}`) !== (address.split("@").pop() || "");

  return (
    <div className="preview">
      <div className="preview-head">
        <span className="preview-avatar">{name.slice(0, 1).toUpperCase()}</span>
        <div>
          <strong>{name}</strong>
          <small>{address}</small>
        </div>
      </div>

      <h4 className="preview-subject">{headers.subject || "(no subject)"}</h4>

      <dl className="preview-meta">
        <div><dt>To</dt><dd>{headers.to || "—"}</dd></div>
        {replyTo && (
          <div className={redirected ? "flagged" : ""}>
            <dt>Replies go to</dt>
            <dd>{replyTo}</dd>
          </div>
        )}
      </dl>

      <div className="preview-body">
        {plain.split("\n").filter(Boolean).map((line, index) => (
          <p key={`${index}-${line.slice(0, 12)}`}>{line}</p>
        ))}
      </div>

      {links.length > 0 && (
        <div className="preview-links">
          <p>Links in this email</p>
          {links.map((link) => {
            const mismatch = link.label && !link.href.toLowerCase().includes(link.label.toLowerCase().replace(/^www\./, ""));
            return (
              <div key={link.href + link.label} className={mismatch ? "flagged" : ""}>
                <span>{link.label || hostOf(link.href) || link.href}</span>
                <Link2 size={13} />
                <code>{link.href}</code>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------- inspector */

function Inspector({ onSaved }) {
  const [tab, setTab] = useState("text");
  const [message, setMessage] = useState("");
  const [rawEmail, setRawEmail] = useState("");
  const [emailView, setEmailView] = useState("raw");
  const [file, setFile] = useState(null);
  const [audioFile, setAudioFile] = useState(null);
  const [transcript, setTranscript] = useState("");
  const [recording, setRecording] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [caps, setCaps] = useState(null);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const recognitionRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);

  useEffect(() => {
    fetch(`${API_BASE}/api/capabilities`)
      .then((response) => (response.ok ? response.json() : null))
      .then(setCaps)
      .catch(() => setCaps(null));
  }, []);

  const stopStream = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  };

  useEffect(() => () => stopStream(), []);

  const send = async (path, init) => {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`${API_BASE}${path}`, init);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "That input could not be analyzed.");
      setResult(data);
      onSaved?.();
    } catch (err) {
      setError(
        err.message === "Failed to fetch"
          ? "The Flask API is not answering. Start it with python backend/app.py."
          : err.message
      );
    } finally {
      setBusy(false);
    }
  };

  const run = () => {
    if (tab === "text") {
      if (!message.trim()) return setError("Paste a message first.");
      return send("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
    }
    if (tab === "email") {
      if (!rawEmail.trim()) return setError("Paste the email, headers included.");
      return send("/api/analyze-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raw: rawEmail }),
      });
    }
    if (tab === "document") {
      if (!file) return setError("Choose a file first.");
      const form = new FormData();
      form.append("file", file);
      return send("/api/analyze-file", { method: "POST", body: form });
    }
    if (audioFile) {
      const form = new FormData();
      form.append("file", audioFile);
      return send("/api/analyze-audio", { method: "POST", body: form });
    }
    if (transcript.trim().length >= 4) {
      return send("/api/analyze-audio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript }),
      });
    }
    return setError("Record something, upload a voice note, or type what the caller said.");
  };

  const serverTranscribes = Boolean(caps?.voice?.server_transcription);
  const SpeechRecognition =
    typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);

  const startRecording = async () => {
    setError("");
    setResult(null);
    if (serverTranscribes) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        chunksRef.current = [];
        const recorder = new MediaRecorder(stream);
        recorder.ondataavailable = (event) => event.data.size && chunksRef.current.push(event.data);
        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: "audio/webm" });
          setAudioFile(new File([blob], "recording.webm", { type: "audio/webm" }));
          stopStream();
        };
        recorder.start();
        recorderRef.current = recorder;
        setRecording(true);
      } catch {
        setError("The microphone is blocked. Allow it in your browser, or upload a file instead.");
      }
      return;
    }
    if (!SpeechRecognition) {
      setError("This browser cannot listen. Use Chrome, upload a voice note, or type the transcript.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-SG";
    let settled = "";
    recognition.onresult = (event) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const chunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) settled += `${chunk} `;
        else interim += chunk;
      }
      setTranscript((settled + interim).trim());
    };
    recognition.onerror = (event) => {
      setError(
        event.error === "not-allowed"
          ? "The microphone is blocked. Allow it in your browser settings."
          : "Listening stopped unexpectedly. Try again, or type the transcript."
      );
      setRecording(false);
    };
    recognition.onend = () => setRecording(false);
    recognition.start();
    recognitionRef.current = recognition;
    setRecording(true);
  };

  const stopRecording = () => {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    recognitionRef.current?.stop();
    setRecording(false);
  };

  const choose = (chosen, kind) => {
    if (!chosen) return;
    setError("");
    setResult(null);
    if (kind === "audio") {
      setAudioFile(chosen);
      setTranscript("");
    } else {
      setFile(chosen);
    }
  };

  const onDrop = (event) => {
    event.preventDefault();
    setDragging(false);
    choose(event.dataTransfer.files?.[0], tab === "voice" ? "audio" : "document");
  };

  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) (tab === "email" ? setRawEmail : setMessage)(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      setError("The clipboard is blocked. Use Ctrl + V instead.");
    }
  };

  const reset = () => {
    setResult(null);
    setMessage("");
    setRawEmail("");
    setFile(null);
    setAudioFile(null);
    setTranscript("");
    setError("");
  };

  const switchTo = (id) => {
    setTab(id);
    setError("");
    setResult(null);
  };

  const cta = {
    text: "Check this message",
    email: "Check this email",
    document: "Check this file",
    voice: "Check this call",
  }[tab];

  const formats = caps?.document
    ? [caps.document.pdf && "PDF", caps.document.docx && "Word", "text", caps.document.image_ocr && "screenshots"]
        .filter(Boolean)
        .join(" · ")
    : "PDF · Word · text · screenshots";

  return (
    <section className="inspector" id="inspector">
      <div className="shell">
        <div className="bench">
          <div className="rail" role="tablist" aria-label="Input type">
            {INPUTS.map(({ id, label, hint, icon: Icon }) => (
              <button
                key={id}
                role="tab"
                aria-selected={tab === id}
                className={tab === id ? "rail-item active" : "rail-item"}
                onClick={() => switchTo(id)}
              >
                <Icon size={17} />
                <span>
                  <strong>{label}</strong>
                  <small>{hint}</small>
                </span>
              </button>
            ))}
            <p className="rail-note">
              <LockKeyhole size={13} />
              Analysed by your own Flask server. No external AI service is called.
            </p>
          </div>

          <div className="stage">
            {tab === "text" && (
              <>
                <div className="field">
                  <textarea
                    id="message-input"
                    value={message}
                    onChange={(event) => { setMessage(event.target.value); setError(""); }}
                    placeholder="Paste the SMS or chat message here…"
                    maxLength={5000}
                  />
                  <button className="chip-btn" onClick={paste} type="button">
                    {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Pasted" : "Paste"}
                  </button>
                  <span className="counter">{message.length} / 5000</span>
                </div>
                <div className="examples">
                  <p>Try one</p>
                  <div>
                    {EXAMPLES.map((example) => (
                      <button
                        key={example.label}
                        className={`example ${example.tone}`}
                        onClick={() => { setMessage(example.text); setResult(null); setError(""); }}
                      >
                        {example.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {tab === "email" && (
              <>
                <div className="view-toggle" role="tablist" aria-label="Email view">
                  <button
                    role="tab"
                    aria-selected={emailView === "readable"}
                    className={emailView === "readable" ? "active" : ""}
                    onClick={() => setEmailView("readable")}
                  >
                    Readable
                  </button>
                  <button
                    role="tab"
                    aria-selected={emailView === "raw"}
                    className={emailView === "raw" ? "active" : ""}
                    onClick={() => setEmailView("raw")}
                  >
                    Raw source
                  </button>
                </div>

                {emailView === "readable" ? (
                  <EmailPreview raw={rawEmail} />
                ) : (
                  <>
                    <p className="note lead">
                      <Mail size={14} />
                      Paste the email&apos;s raw source, headers included, because that is where the
                      evidence lives. Gmail: open the message, click ⋮, then Show original.
                      Outlook: File → Properties → Internet headers, plus the body.
                    </p>
                    <div className="field">
                      <textarea
                        className="mono"
                        value={rawEmail}
                        onChange={(event) => { setRawEmail(event.target.value); setError(""); }}
                        placeholder="Paste the full email source here…"
                      />
                      <button className="chip-btn" onClick={paste} type="button">
                        {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Pasted" : "Paste"}
                      </button>
                    </div>
                  </>
                )}
                <p className="note">
                  <Fingerprint size={14} />
                  Headers get their own check: spoofed senders, a hijacked Reply-To, failed SPF,
                  DKIM or DMARC, and links whose visible text hides where they really go.
                </p>
                <button
                  className="btn btn-outline"
                  onClick={() => { setRawEmail(EMAIL_SAMPLE); setEmailView("readable"); setResult(null); setError(""); }}
                >
                  Load a phishing sample
                </button>
              </>
            )}

            {tab === "document" && (
              <>
                <label
                  className={`dropzone ${dragging ? "over" : ""}`}
                  onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={onDrop}
                >
                  <input type="file" hidden onChange={(event) => choose(event.target.files?.[0], "document")} />
                  <Upload size={22} />
                  <strong>{file ? file.name : "Drop a file, or click to browse"}</strong>
                  <small>{file ? `${(file.size / 1024).toFixed(0)} KB · click to replace` : formats}</small>
                </label>
                <p className="note">
                  <Link2 size={14} />
                  Beyond the wording, files are checked for what never shows on screen: script
                  buried in a PDF, macros in a Word file, and attachments disguised with a second
                  file extension.
                </p>
              </>
            )}

            {tab === "voice" && (
              <>
                <button
                  className={`record ${recording ? "on" : ""}`}
                  onClick={recording ? stopRecording : startRecording}
                >
                  <span className="record-icon">{recording ? <Square size={16} /> : <Mic size={16} />}</span>
                  {recording ? "Stop recording" : "Start recording"}
                </button>
                <p className="note">
                  <Radio size={14} />
                  {serverTranscribes
                    ? `Speech is transcribed on the server with ${caps.voice.engine}.`
                    : "Speech is transcribed by your browser. Chrome handles this best."}
                </p>
                <label
                  className={`dropzone slim ${dragging ? "over" : ""}`}
                  onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={onDrop}
                >
                  <input type="file" hidden accept="audio/*" onChange={(event) => choose(event.target.files?.[0], "audio")} />
                  <Upload size={15} />
                  <strong>{audioFile ? audioFile.name : "Or upload a voice note"}</strong>
                </label>
                <div className="field">
                  <textarea
                    value={transcript}
                    onChange={(event) => { setTranscript(event.target.value); setAudioFile(null); setError(""); }}
                    placeholder="The transcript builds here as you speak. You can also type what the caller said."
                  />
                </div>
              </>
            )}

            {error && <p className="error"><CircleAlert size={15} /> {error}</p>}

            <button className="btn btn-solid btn-lg run" onClick={run} disabled={busy}>
              {busy ? <><LoaderCircle className="spin" size={17} /> Working</> : <>{cta} <ArrowRight size={17} /></>}
            </button>
          </div>

          <div className={`readout ${busy ? "busy" : ""}`} aria-live="polite">
            <div className="readout-bar">
              <span>{busy ? "Reading input" : "Result"}</span>
              <span className="readout-id">Scam Radar 2.0</span>
            </div>
            <span className="beam" aria-hidden="true" />
            <div className="readout-body">
              {result && !busy ? <Verdict result={result} onReset={reset} /> : <Waiting busy={busy} />}
            </div>
          </div>
        </div>

        <p className="disclaimer">
          A second opinion, not a guarantee. Anything involving money or credentials deserves a
          call to a number you already had.
        </p>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- method */

function Method() {
  return (
    <section className="method" id="method">
      <div className="shell">
        <ol className="steps">
          {STEPS.map((step, index) => (
            <li key={step.title}>
              <span className="step-no">{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Figure({ value, label, sub, active }) {
  const shown = useCountUp(value, 1300, active);
  return (
    <div className="figure">
      <strong>{shown}</strong>
      <span>{label}</span>
      <small>{sub}</small>
    </div>
  );
}

function Figures() {
  const [ref, seen] = useInView(0.4);
  const figures = [
    [4, "ways in", "text, email, file, voice"],
    [38, "brands watched", "banks, agencies, marketplaces"],
    [100, "training messages", "written for Singapore"],
    [0, "external AI calls", "everything runs locally"],
  ];
  return (
    <section className="figures" ref={ref}>
      <div className="shell figures-grid">
        {figures.map(([value, label, sub]) => (
          <Figure key={label} value={value} label={label} sub={sub} active={seen} />
        ))}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ quiz */

function Quiz() {
  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState(null);
  const [marked, setMarked] = useState(null);
  const [score, setScore] = useState(0);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const start = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API_BASE}/api/quiz`);
      if (!response.ok) throw new Error("The quiz could not be loaded.");
      const data = await response.json();
      setQuestions(data.questions);
      setIndex(0);
      setPicked(null);
      setMarked(null);
      setScore(0);
      setSummary(null);
    } catch (err) {
      setError(err.message === "Failed to fetch" ? "The Flask API is not answering." : err.message);
    } finally {
      setLoading(false);
    }
  };

  const answer = async (choice) => {
    if (marked) return;
    setPicked(choice);
    try {
      const response = await fetch(`${API_BASE}/api/quiz/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: questions[index].id, choice }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "That answer could not be marked.");
      setMarked(data);
      if (data.correct) setScore((n) => n + 1);
    } catch (err) {
      setError(err.message);
      setPicked(null);
    }
  };

  const next = async () => {
    const finalScore = score;
    if (index + 1 < questions.length) {
      setIndex(index + 1);
      setPicked(null);
      setMarked(null);
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/api/quiz/result`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ score: finalScore, total: questions.length }),
      });
      setSummary(await response.json());
    } catch {
      setSummary({ score: finalScore, total: questions.length, headline: "Round finished.", note: "" });
    }
  };

  const question = questions[index];
  const progress = questions.length ? ((index + (marked ? 1 : 0)) / questions.length) * 100 : 0;

  return (
    <section className="quiz" id="quiz">
      <div className="shell quiz-grid">
        <div className="quiz-side">
          <p className="quiz-blurb">
            Answers are marked on the server, so there is nothing to peek at in the page source.
            Each round is a fresh draw, and the explanations are the part worth reading.
          </p>
          {!questions.length && !loading && (
            <button className="btn btn-solid btn-lg quiz-start" onClick={start}>
              Start the quiz <ArrowRight size={17} />
            </button>
          )}
          {error && <p className="error quiz-error"><CircleAlert size={15} /> {error}</p>}
        </div>

        <div className="quiz-card">
          {loading && <p className="quiz-idle"><LoaderCircle className="spin" size={16} /> Picking five questions</p>}

          {!loading && !questions.length && !error && (
            <div className="quiz-idle">
              <Brain size={26} />
              <p>Most people miss at least one. The explanations are the part worth reading.</p>
            </div>
          )}

          {!loading && summary && (
            <div className="quiz-summary">
              <strong>{summary.score}<i>/{summary.total}</i></strong>
              <h3>{summary.headline}</h3>
              <p>{summary.note}</p>
              <button className="btn btn-outline" onClick={start}>
                <RotateCcw size={14} /> Try a fresh set
              </button>
            </div>
          )}

          {!loading && question && !summary && (
            <>
              <div className="quiz-bar">
                <span>Question {index + 1} of {questions.length}</span>
                <span>{score} right so far</span>
              </div>
              <div className="quiz-track"><i style={{ width: `${progress}%` }} /></div>

              <h3 className="quiz-prompt">{question.prompt}</h3>

              <div className="quiz-options">
                {question.options.map((option, choice) => {
                  const isAnswer = marked && choice === marked.answer;
                  const isWrongPick = marked && choice === picked && !marked.correct;
                  return (
                    <button
                      key={option}
                      className={`quiz-option ${isAnswer ? "right" : ""} ${isWrongPick ? "wrong" : ""}`}
                      onClick={() => answer(choice)}
                      disabled={Boolean(marked)}
                    >
                      <span className="quiz-key">{String.fromCharCode(65 + choice)}</span>
                      {option}
                      {isAnswer && <CircleCheck size={17} />}
                      {isWrongPick && <CircleAlert size={17} />}
                    </button>
                  );
                })}
              </div>

              {marked && (
                <div className={`quiz-explain ${marked.correct ? "right" : "wrong"}`}>
                  <strong>{marked.correct ? "Correct." : "Not this time."}</strong>
                  <p>{marked.explanation}</p>
                  <button className="btn btn-solid" onClick={next}>
                    {index + 1 < questions.length ? "Next question" : "See how you did"}
                    <ArrowRight size={15} />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </section>
  );
}

/* --------------------------------------------------------------- history */

const SOURCE_ICON = { email: Mail, document: FileText, voice: Mic, text: MessageSquareText };

function HistorySection({ refreshToken }) {
  const [items, setItems] = useState([]);
  const [summary, setSummary] = useState({ total: 0, scams: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/history?limit=30`);
      if (!response.ok) throw new Error("History could not be loaded.");
      const data = await response.json();
      setItems(data.items);
      setSummary(data.summary);
      setError("");
    } catch (err) {
      setError(err.message === "Failed to fetch" ? "The Flask API is not answering." : err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [refreshToken]);

  const remove = async (id) => {
    await fetch(`${API_BASE}/api/history/${id}`, { method: "DELETE" });
    load();
  };

  const clearAll = async () => {
    await fetch(`${API_BASE}/api/history`, { method: "DELETE" });
    load();
  };

  const rate = summary.total ? Math.round((summary.scams / summary.total) * 100) : 0;

  return (
    <section className="history" id="history">
      <div className="shell">
        <div className="history-top">
          <div className="history-stats">
            <div><strong>{summary.total}</strong><span>checked</span></div>
            <div><strong>{rate}%</strong><span>flagged</span></div>
            {items.length > 0 && (
              <button className="btn btn-outline" onClick={clearAll}><Trash2 size={14} /> Clear all</button>
            )}
          </div>
        </div>

        {loading ? (
          <p className="history-state"><LoaderCircle className="spin" size={16} /> Loading</p>
        ) : error ? (
          <p className="history-state err"><CircleAlert size={16} /> {error}</p>
        ) : !items.length ? (
          <div className="history-empty">
            <p>Nothing checked yet.</p>
            <Link to="/scan" className="btn btn-solid">Check something <ArrowUpRight size={15} /></Link>
          </div>
        ) : (
          <ul className="rows">
            {items.map((item) => {
              const Icon = SOURCE_ICON[item.source] || MessageSquareText;
              const when = new Date(item.created_at);
              const bad = item.verdict === "SCAM";
              return (
                <li key={item.id}>
                  <span className={`row-icon ${bad ? "bad" : "good"}`}><Icon size={15} /></span>
                  <p className="row-text">{item.message}</p>
                  <span className={`pill ${bad ? "bad" : "good"}`}>{bad ? "Scam" : "Clear"}</span>
                  <span className="row-conf">
                    {Math.round(item.confidence)}%
                    <i><b style={{ width: `${item.confidence}%` }} /></i>
                  </span>
                  <span className="row-when">
                    {when.toLocaleDateString(undefined, { day: "2-digit", month: "short" })}
                    <small>{when.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}</small>
                  </span>
                  <button className="row-x" onClick={() => remove(item.id)} aria-label="Delete this scan">
                    <X size={15} />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------- faq */

function FAQ() {
  const [open, setOpen] = useState(0);
  return (
    <section className="faq" id="faq">
      <div className="shell">
        <div className="faq-list">
          {FAQS.map((item, index) => (
            <div key={item.q} className={open === index ? "faq-item open" : "faq-item"}>
              <button onClick={() => setOpen(open === index ? -1 : index)}>
                {item.q}
                <ChevronDown size={17} />
              </button>
              <div className="faq-body"><p>{item.a}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="shell footer-inner">
        <div className="footer-brand">
          <Wordmark />
          <p>An explainable scam detector. Python, Flask, scikit-learn and React, built as a third-year project in Singapore.</p>
        </div>
        <nav className="footer-links">
          {ROUTES.map(({ path, label }) => (
            <Link key={path} to={path}>{label}</Link>
          ))}
        </nav>
        <p className="footer-fine">
          Lost money to a scam in Singapore? Call the ScamShield helpline on 1799 or make a police
          report. This project is coursework, not a reporting channel.
        </p>
      </div>
    </footer>
  );
}

/* ------------------------------------------------------------------ home */

const SIGNPOSTS = [
  {
    to: "/scan",
    icon: ScanLine,
    title: "Scan something",
    body: "A text, an email with its headers, a PDF or screenshot, or a recorded call. One verdict with the evidence attached.",
  },
  {
    to: "/method",
    icon: Fingerprint,
    title: "See how it decides",
    body: "Two TF-IDF views over the wording, a forensic pass over the structure, and a blend that no single finding can dominate.",
  },
  {
    to: "/quiz",
    icon: Brain,
    title: "Test yourself",
    body: "Five questions per round from a bank of fifteen. Most people miss at least one.",
  },
  {
    to: "/history",
    icon: History,
    title: "Look back",
    body: "Every scan you have run, tagged by input type and kept in a local file you can wipe.",
  },
];

function Signposts() {
  return (
    <section className="signposts">
      <div className="shell">
        <div className="signpost-grid">
          {SIGNPOSTS.map(({ to, icon: Icon, title, body }) => (
            <Link key={to} to={to} className="signpost">
              <span className="signpost-icon"><Icon size={19} /></span>
              <h3>{title}</h3>
              <p>{body}</p>
              <span className="signpost-go">Open <ArrowUpRight size={15} /></span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function Home() {
  return (
    <>
      <Hero />
      <Signposts />
      <Figures />
    </>
  );
}

function PageHead({ title, lead }) {
  return (
    <div className="page-head">
      <div className="shell">
        <h1>{title}</h1>
        <p>{lead}</p>
      </div>
    </div>
  );
}

function NotFound() {
  return (
    <>
      <PageHead title="No such page" lead="That address does not match anything here." />
      <section className="notfound">
        <div className="shell">
          <Link to="/" className="btn btn-solid btn-lg">Back to the start <ArrowRight size={17} /></Link>
        </div>
      </section>
    </>
  );
}

/* ------------------------------------------------------------------- app */

export default function App() {
  const route = useRoute();
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, [route]);

  // Re-run the reveal observer whenever a new page mounts.
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add("seen")),
      { threshold: 0.06 }
    );
    document.querySelectorAll("section").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [route]);

  const page = {
    "/": <Home />,
    "/scan": (
      <>
        <PageHead title="Put it on the bench" lead="Four ways in. One verdict, with the reasoning attached." />
        <Inspector onSaved={() => setRefresh((n) => n + 1)} />
      </>
    ),
    "/method": (
      <>
        <PageHead title="Two readings of the same thing" lead="Wording is half of it. The rest is in the plumbing." />
        <Method />
        <Figures />
      </>
    ),
    "/quiz": (
      <>
        <PageHead title="Would you have caught it?" lead="Five questions, drawn at random from a larger set." />
        <Quiz />
      </>
    ),
    "/history": (
      <>
        <PageHead title="Everything you have checked" lead="Kept in a local SQLite file. Yours to delete." />
        <HistorySection refreshToken={refresh} />
      </>
    ),
    "/faq": (
      <>
        <PageHead title="Questions worth asking" lead="Especially the last one." />
        <FAQ />
      </>
    ),
  }[route] || <NotFound />;

  return (
    <>
      <Header route={route} />
      <main key={route} className={route === "/" ? "page page-home" : "page"}>
        {page}
      </main>
      <Footer />
    </>
  );
}
